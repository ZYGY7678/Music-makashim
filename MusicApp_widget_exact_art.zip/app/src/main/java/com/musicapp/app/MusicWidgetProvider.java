package com.musicapp.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.database.Cursor;
import android.provider.MediaStore;
import android.net.Uri;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.widget.RemoteViews;

import com.musicapp.app.service.MusicService;

public class MusicWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_WIDGET_UPDATE = "com.musicapp.app.WIDGET_UPDATE";
    public static final String EXTRA_TITLE = "widget_title";
    public static final String EXTRA_ARTIST = "widget_artist";
    public static final String EXTRA_PATH = "widget_path";
    public static final String EXTRA_PLAYING = "widget_playing";
    public static final String EXTRA_SONG_ID = "widget_song_id";
    public static final String EXTRA_NEXT1 = "widget_next1";
    public static final String EXTRA_NEXT2 = "widget_next2";
    public static final String EXTRA_NEXT3 = "widget_next3";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        updateAll(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_WIDGET_UPDATE.equals(intent.getAction())) {
            updateAll(context, intent.getStringExtra(EXTRA_TITLE),
                    intent.getStringExtra(EXTRA_ARTIST), intent.getStringExtra(EXTRA_PATH),
                    intent.getLongExtra(EXTRA_SONG_ID, -1L),
                    intent.getBooleanExtra(EXTRA_PLAYING, false),
                    intent.getStringExtra(EXTRA_NEXT1), intent.getStringExtra(EXTRA_NEXT2), intent.getStringExtra(EXTRA_NEXT3));
        }
    }

    private static void updateAll(Context context) {
        updateAll(context, "אין שיר מתנגן", "", null, -1L, false, "", "", "");
    }

    private static void updateAll(Context context, String title, String artist, String path, long songId, boolean playing, String next1, String next2, String next3) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, MusicWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateOne(context, manager, id, title, artist, path, songId, playing, next1, next2, next3);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id,
                                  String title, String artist, String path, long songId, boolean playing, String next1, String next2, String next3) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_music);
        views.setTextViewText(R.id.widget_title, title == null || title.isEmpty() ? "אין שיר מתנגן" : title);
        views.setTextViewText(R.id.widget_artist, artist == null ? "" : artist);
        views.setTextViewText(R.id.widget_play_pause, playing ? "⏸" : "▶");
        views.setTextViewText(R.id.widget_next1, formatNext(next1));
        views.setTextViewText(R.id.widget_next2, formatNext(next2));
        views.setTextViewText(R.id.widget_next3, formatNext(next3));

        Bitmap art = loadArtwork(context, path, songId);
        if (art != null) {
            views.setImageViewBitmap(R.id.widget_album_art, art);
        } else {
            views.setImageViewResource(R.id.widget_album_art, R.drawable.default_album_art);
        }

        views.setOnClickPendingIntent(R.id.widget_play_pause, serviceIntent(context, MusicService.ACTION_PLAY_PAUSE, 101));
        views.setOnClickPendingIntent(R.id.widget_prev, serviceIntent(context, MusicService.ACTION_PREV, 102));
        views.setOnClickPendingIntent(R.id.widget_next, serviceIntent(context, MusicService.ACTION_NEXT, 103));
        views.setOnClickPendingIntent(R.id.widget_album_art, mainIntent(context));
        views.setOnClickPendingIntent(R.id.widget_title, mainIntent(context));
        views.setOnClickPendingIntent(R.id.widget_artist, mainIntent(context));

        manager.updateAppWidget(id, views);
    }

    private static String formatNext(String value) {
        return value == null || value.trim().isEmpty() ? "" : "• " + value;
    }

    private static PendingIntent serviceIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, MusicService.class);
        intent.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getService(context, requestCode, intent, flags);
    }

    private static PendingIntent mainIntent(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, 104, intent, flags);
    }

    private static Bitmap loadArtwork(Context context, String path, long songId) {
        // Prefer the artwork embedded in THIS exact audio file. Album-art lookup by
        // ALBUM_ID can return artwork shared by another track in the same album.
        if (songId >= 0) {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            try {
                Uri songUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId);
                retriever.setDataSource(context, songUri);
                byte[] embedded = retriever.getEmbeddedPicture();
                Bitmap exact = decodeSampledArtwork(embedded);
                if (exact != null) return exact;
            } catch (Throwable ignored) {
                // Fall back to MediaStore album artwork below.
            } finally {
                try { retriever.release(); } catch (Throwable ignored) {}
            }
        }

        // Fallback only when the file has no embedded artwork.
        if (path == null || path.isEmpty()) return null;
        Cursor c = null;
        java.io.InputStream in = null;
        try {
            String[] projection = { MediaStore.Audio.Media.ALBUM_ID };
            c = context.getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection,
                    MediaStore.Audio.Media.DATA + "=?", new String[]{path}, null);
            if (c == null || !c.moveToFirst()) return null;
            long albumId = c.getLong(0);
            if (albumId < 0) return null;
            Uri artUri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), albumId);
            in = context.getContentResolver().openInputStream(artUri);
            if (in == null) return null;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 2;
            return BitmapFactory.decodeStream(in, null, opts);
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (Throwable ignored) {}
            if (c != null) try { c.close(); } catch (Throwable ignored) {}
        }
    }

    private static Bitmap decodeSampledArtwork(byte[] data) {
        if (data == null || data.length == 0) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            int sample = 1;
            while (max / sample > 1024) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        } catch (Throwable ignored) {
            return null;
        }
    }
}
