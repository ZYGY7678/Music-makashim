package com.musicapp.app.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.media.app.NotificationCompat.MediaStyle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.musicapp.app.MainActivity;
import com.musicapp.app.R;
import com.musicapp.app.models.Song;

import java.util.ArrayList;
import java.util.List;

public class MusicService extends Service implements
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnErrorListener {

    public static final String ACTION_PLAY_PAUSE = "com.musicapp.app.PLAY_PAUSE";
    public static final String ACTION_NEXT       = "com.musicapp.app.NEXT";
    public static final String ACTION_PREV       = "com.musicapp.app.PREV";
    public static final String ACTION_STOP       = "com.musicapp.app.STOP";

    private static final String CHANNEL_ID       = "MusicAppChannel";
    private static final int    NOTIF_ID         = 1;

    public interface MusicCallback {
        void onSongChanged(Song song);
        void onPlayStateChanged(boolean isPlaying);
        void onProgress(int currentMs, int totalMs);
    }

    private final IBinder binder = new MusicBinder();
    private MediaPlayer player;
    private Equalizer equalizer;
    private List<Song> queue = new ArrayList<>();
    private int currentIndex = -1;
    private MusicCallback callback;
    private boolean prepared = false;
    private int playRequestId = 0;
    private boolean pauseOnNextPrepare = false;

    // טיימר שינה
    private Handler sleepTimerHandler = new Handler();
    private Runnable sleepTimerRunnable;
    private long sleepTimerEndAt = 0;
    private int sleepTimerSongsRemaining = 0;
    private boolean sleepTimerStopAtSongEnd = false;

    // עצירה אוטומטית
    private AudioManager audioManager;
    private AudioManager.OnAudioFocusChangeListener audioFocusListener;
    private PhoneStateListener phoneStateListener;
    private TelephonyManager telephonyManager;
    private BroadcastReceiver bluetoothReceiver;
    private BroadcastReceiver mediaButtonReceiver;
    private boolean pausedByInterruption = false;
    private boolean playerError = false;

    // מינימום השמעה לספירה (30 שניות)
    private static final int MIN_PLAY_SECONDS_FOR_COUNT = 30;
    private Handler playCountHandler = new Handler();
    private Runnable playCountRunnable;
    private long currentSongId = -1;

    public class MusicBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        createPlayer();
        setupInterruptListeners();
        registerMediaButtonReceiver();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_PLAY_PAUSE:
                    togglePlayPause();
                    break;
                case ACTION_NEXT:
                    playNext();
                    break;
                case ACTION_PREV:
                    playPrevious();
                    break;
                case ACTION_STOP:
                    stopForeground(true);
                    stopSelf();
                    break;
            }
        }
        return START_STICKY;
    }

    public void setCallback(MusicCallback cb) {
        this.callback = cb;
    }

    public void setQueue(List<Song> songs, int startIndex) {
        queue.clear();
        if (songs != null) { for (Song s : songs) if (s != null) queue.add(s); }
        playSongAtIndex(startIndex);
    }

    public void loadQueuePaused(List<Song> songs, int startIndex) {
        queue.clear();
        if (songs != null) { for (Song s : songs) if (s != null) queue.add(s); }
        loadSongAtIndexPaused(startIndex);
    }

    public void loadSongAtIndexPaused(int index) {
        if (queue.isEmpty() || index < 0 || index >= queue.size()) return;
        currentIndex = index;
        Song song = queue.get(currentIndex);
        prepared = false;
        pauseOnNextPrepare = true;
        try {
            player.reset();
            player.setDataSource(song.getPath());
            player.prepareAsync();
        } catch (Exception e) {
            e.printStackTrace();
            pauseOnNextPrepare = false;
            return;
        }
        if (callback != null) callback.onSongChanged(song);
    }

    public void insertNext(List<Song> songs) {
        int insertAt = currentIndex + 1;
        for (int i = songs.size() - 1; i >= 0; i--) {
            queue.add(insertAt, songs.get(i));
        }
    }

    public void addToEnd(List<Song> songs) {
        queue.addAll(songs);
    }

    /** הסרת שיר מהתור לפי אינדקס */
    public void removeFromQueue(int index) {
        if (index < 0 || index >= queue.size()) return;
        if (index == currentIndex) {
            // אם מסירים את השיר הנוכחי — עוצרים
            try {
                if (prepared && player.isPlaying()) player.stop();
            } catch (Exception ignored) {}
            prepared = false;
        }
        queue.remove(index);
        if (index < currentIndex) {
            currentIndex--;
        } else if (index == currentIndex && !queue.isEmpty()) {
            // מתחילים לנגן את הבא (שכבר הגיע למקומו)
            if (currentIndex >= queue.size()) currentIndex = 0;
            playSongAtIndex(currentIndex);
        }
    }

    public void playFromUri(Uri uri) {
        prepared = false;
        try {
            player.reset();
            player.setDataSource(getApplicationContext(), uri);
            player.prepareAsync();
            Song temp = new Song(-1, uri.getLastPathSegment(), "", "", "", 0, 0,
                    uri.getPath() != null ? uri.getPath() : "", -1);
            queue.clear();
            queue.add(temp);
            currentIndex = 0;
            if (callback != null) callback.onSongChanged(temp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void playSongAtIndex(int index) {
        if (queue.isEmpty() || index < 0 || index >= queue.size()) return;
        currentIndex = index;
        Song song = queue.get(currentIndex);
        prepared = false;
        playerError = false;
        cancelPlayCountTimer();
        try {
            if (player == null) createPlayer();
            else { try { player.reset(); } catch (Throwable ignored) { recreatePlayer(); } }
            String path = song != null ? song.getPath() : null;
            if (path == null || path.trim().isEmpty()) {
                handleBadTrackAndContinue();
                return;
            }
            player.setDataSource(path);
            player.prepareAsync();
        } catch (Throwable e) {
            handleBadTrackAndContinue();
            return;
        }
        try { if (callback != null) callback.onSongChanged(song); } catch (Throwable ignored) {}
        try { broadcastWidgetState(false); } catch (Throwable ignored) {}
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        if (mp != player || playerError) return;
        prepared = true;

        if (pauseOnNextPrepare) {
            pauseOnNextPrepare = false;
            if (callback != null) callback.onPlayStateChanged(false);
            updateNotification(false);
            broadcastWidgetState(false);
            return;
        }

        try {
            if (audioManager != null && audioFocusListener != null) {
                audioManager.requestAudioFocus(audioFocusListener,
                        AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
            mp.start();
        } catch (Exception e) {
            e.printStackTrace();
            prepared = false;
            return;
        }
        try { if (callback != null) callback.onPlayStateChanged(true); } catch (Throwable ignored) {}
        try { broadcastWidgetState(true); } catch (Throwable ignored) {}

        Song current = getCurrentSong();
        if (current != null) {
            currentSongId = current.getId();
            schedulePlayCount(current.getId());
        }
        try { updateNotification(true); } catch (Throwable ignored) {}
        try { onSongStartedForSleepTimer(); } catch (Throwable ignored) {}
    }

    // ===================== ספירת השמעה עם מינימום 30 שניות =====================

    private void schedulePlayCount(final long songId) {
        cancelPlayCountTimer();
        playCountRunnable = new Runnable() {
            @Override
            public void run() {
                // ורק אם עדיין מנגנים את אותו שיר
                if (songId == currentSongId && prepared && player != null) {
                    try {
                        if (player.isPlaying()) {
                            new com.musicapp.app.utils.AppPreferences(getApplicationContext())
                                    .recordSongPlayed(songId);
                        }
                    } catch (Exception ignored) {}
                }
            }
        };
        playCountHandler.postDelayed(playCountRunnable, MIN_PLAY_SECONDS_FOR_COUNT * 1000L);
    }

    private void cancelPlayCountTimer() {
        if (playCountRunnable != null) {
            playCountHandler.removeCallbacks(playCountRunnable);
            playCountRunnable = null;
        }
    }

    /** מעדכן את ווידג'ט מסך הבית במצב ובשיר הנוכחי. */
    private void broadcastWidgetState(boolean playing) {
        Song song = getCurrentSong();
        Intent intent = new Intent("com.musicapp.app.WIDGET_UPDATE");
        if (song != null) {
            intent.putExtra("widget_title", song.getTitle());
            intent.putExtra("widget_artist", song.getArtist());
            intent.putExtra("widget_path", song.getPath());
            intent.putExtra("widget_song_id", song.getId());
        }
        // Send the next three queue entries so the home-screen widget can show what is coming.
        int size = queue == null ? 0 : queue.size();
        for (int offset = 1; offset <= 3; offset++) {
            String key = "widget_next" + offset;
            String value = "";
            if (size > 0 && currentIndex >= 0) {
                int idx = (currentIndex + offset) % size;
                if (idx >= 0 && idx < size && queue.get(idx) != null) {
                    Song next = queue.get(idx);
                    value = next.getTitle() == null ? "" : next.getTitle();
                }
            }
            intent.putExtra(key, value);
        }
        intent.putExtra("widget_playing", playing);
        sendBroadcast(intent);
    }

    // ===================== NOTIFICATION =====================

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "נגן מוזיקה",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("שליטה בנגן המוזיקה");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private PendingIntent makeActionIntent(String action) {
        Intent i = new Intent(this, MusicService.class);
        i.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getService(this, action.hashCode(), i, flags);
    }

    private PendingIntent makeMainIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(this, 0, i, flags);
    }

    private void updateNotification(boolean playing) {
        Song song = getCurrentSong();
        String title  = (song != null) ? song.getTitle()  : "מוזיקה";
        String artist = (song != null) ? song.getArtist() : "";

        // Do not decode embedded artwork here. Some malformed/huge embedded images can
        // crash the native media stack. The widget/UI handle album art independently.
        Bitmap art = null;
        try { art = BitmapFactory.decodeResource(getResources(), R.drawable.default_album_art); } catch (Throwable ignored) {}

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(artist)
                .setLargeIcon(art)
                .setContentIntent(makeMainIntent())
                .setOngoing(playing)
                .setShowWhen(false)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                // כפתורים: קודם | הפסק/המשך | הבא
                .addAction(android.R.drawable.ic_media_previous, "קודם",
                        makeActionIntent(ACTION_PREV))
                .addAction(playing ? android.R.drawable.ic_media_pause
                                   : android.R.drawable.ic_media_play,
                        playing ? "עצור" : "נגן",
                        makeActionIntent(ACTION_PLAY_PAUSE))
                .addAction(android.R.drawable.ic_media_next, "הבא",
                        makeActionIntent(ACTION_NEXT))
                .setStyle(new MediaStyle()
                        .setShowActionsInCompactView(0, 1, 2));

        Notification notif = builder.build();
        if (playing) {
            // Android 14+ requires the mediaPlayback foreground-service type to be
            // declared in the manifest before startForeground() is called.
            startForeground(NOTIF_ID, notif);
        } else {
            stopForeground(false);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, notif);
        }
    }

    // ===================== EQUALIZER =====================

    private void setupEqualizer() {
        try {
            if (equalizer != null) { equalizer.release(); equalizer = null; }
            equalizer = new Equalizer(0, player.getAudioSessionId());
            com.musicapp.app.utils.AppPreferences p =
                    new com.musicapp.app.utils.AppPreferences(getApplicationContext());
            equalizer.setEnabled(p.isEqEnabled());
            applyEqualizerLevels(p.getEqBass(), p.getEqMid(), p.getEqTreble());
        } catch (Exception e) {
            e.printStackTrace();
            equalizer = null;
        }
    }

    public void applyEqualizerLevels(int bass, int mid, int treble) {
        if (equalizer == null) return;
        try {
            short bandCount = equalizer.getNumberOfBands();
            if (bandCount <= 0) return;
            short minLevel = equalizer.getBandLevelRange()[0];
            short maxLevel = equalizer.getBandLevelRange()[1];
            for (short band = 0; band < bandCount; band++) {
                int sliderValue;
                if (band < bandCount / 3.0)          sliderValue = bass;
                else if (band < bandCount * 2.0 / 3.0) sliderValue = mid;
                else                                  sliderValue = treble;
                float fraction = (sliderValue - 50) / 50f;
                short level = fraction >= 0 ? (short)(fraction * maxLevel)
                                            : (short)(-fraction * minLevel);
                equalizer.setBandLevel(band, level);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void setEqualizerEnabled(boolean enabled) {
        if (equalizer != null) {
            try { equalizer.setEnabled(enabled); } catch (Exception e) { e.printStackTrace(); }
        }
        com.musicapp.app.utils.AppPreferences p =
                new com.musicapp.app.utils.AppPreferences(getApplicationContext());
        p.saveEqSettings(p.getEqBass(), p.getEqMid(), p.getEqTreble(), enabled);
    }

    public boolean isEqualizerAvailable() { return equalizer != null; }

    // ===================== SLEEP TIMER =====================

    public void setSleepTimer(int minutes) {
        cancelSleepTimer();
        if (minutes <= 0) return;
        sleepTimerEndAt = System.currentTimeMillis() + minutes * 60L * 1000L;
        sleepTimerRunnable = new Runnable() {
            @Override public void run() {
                sleepTimerEndAt = 0;
                if (prepared && player != null) {
                    try {
                        if (player.isPlaying()) { player.pause(); updateNotification(false); }
                        if (callback != null) callback.onPlayStateChanged(false);
                        broadcastWidgetState(false);
                    } catch (Exception e) { e.printStackTrace(); }
                }
            }
        };
        sleepTimerHandler.postDelayed(sleepTimerRunnable, minutes * 60L * 1000L);
    }

    public void setSleepTimerSongs(int songCount) {
        cancelSleepTimer();
        if (songCount <= 0) return;
        sleepTimerSongsRemaining = songCount;
    }

    public void cancelSleepTimer() {
        if (sleepTimerRunnable != null) {
            sleepTimerHandler.removeCallbacks(sleepTimerRunnable);
            sleepTimerRunnable = null;
        }
        sleepTimerEndAt = 0;
        sleepTimerSongsRemaining = 0;
        sleepTimerStopAtSongEnd = false;
    }

    public boolean isSleepTimerActive() {
        return (sleepTimerEndAt > System.currentTimeMillis()) || (sleepTimerSongsRemaining > 0);
    }

    public boolean isSleepTimerSongMode() { return sleepTimerSongsRemaining > 0; }

    public int getSleepTimerMinutesRemaining() {
        if (sleepTimerEndAt <= System.currentTimeMillis()) return 0;
        long remainingMs = sleepTimerEndAt - System.currentTimeMillis();
        return (int) Math.ceil(remainingMs / 60000.0);
    }

    public int getSleepTimerSongsRemaining() { return sleepTimerSongsRemaining; }

    private void onSongStartedForSleepTimer() {
        if (sleepTimerSongsRemaining <= 0) return;
        sleepTimerSongsRemaining--;
        if (sleepTimerSongsRemaining <= 0) {
            sleepTimerSongsRemaining = 0;
            sleepTimerStopAtSongEnd = true;
        }
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        cancelPlayCountTimer();
        if (sleepTimerStopAtSongEnd) {
            sleepTimerStopAtSongEnd = false;
            try {
                if (callback != null) callback.onPlayStateChanged(false);
                updateNotification(false);
                broadcastWidgetState(false);
            } catch (Exception e) { e.printStackTrace(); }
            return;
        }
        playNext();
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        if (mp != player) return true;
        prepared = false;
        playerError = true;
        cancelPlayCountTimer();
        // Never leave MediaPlayer in its ERROR state. Recreate it before moving on.
        try { recreatePlayer(); } catch (Throwable ignored) {}
        try { if (callback != null) callback.onPlayStateChanged(false); } catch (Throwable ignored) {}
        try { broadcastWidgetState(false); } catch (Throwable ignored) {}
        // A bad/unsupported track must not take down the app. Move to the next one.
        try {
            if (!queue.isEmpty() && queue.size() > 1) {
                playNext();
            } else {
                try { updateNotification(false); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return true;
    }

    private void createPlayer() {
        player = new MediaPlayer();
        player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
        playerError = false;
    }

    private void recreatePlayer() {
        MediaPlayer old = player;
        player = null;
        if (old != null) { try { old.reset(); } catch (Throwable ignored) {} try { old.release(); } catch (Throwable ignored) {} }
        createPlayer();
    }

    private void handleBadTrackAndContinue() {
        prepared = false;
        playerError = true;
        cancelPlayCountTimer();
        try { recreatePlayer(); } catch (Throwable ignored) {}
        if (!queue.isEmpty() && queue.size() > 1) {
            try { playNext(); } catch (Throwable ignored) {}
        } else {
            try { if (callback != null) callback.onPlayStateChanged(false); } catch (Throwable ignored) {}
            try { broadcastWidgetState(false); } catch (Throwable ignored) {}
            try { updateNotification(false); } catch (Throwable ignored) {}
        }
    }

    public void playNext() {
        if (queue.isEmpty()) return;
        int next = currentIndex + 1;
        if (next >= queue.size()) next = 0;
        playSongAtIndex(next);
    }

    public void playPrevious() {
        if (queue.isEmpty()) return;
        int prev = currentIndex - 1;
        if (prev < 0) prev = queue.size() - 1;
        playSongAtIndex(prev);
    }

    public void togglePlayPause() {
        if (!prepared) return;
        try {
            if (player.isPlaying()) {
                player.pause();
                cancelPlayCountTimer();
            } else {
                player.start();
                // אם ממשיכים נגינה — מתחשבים בזמן שכבר עבר
                if (currentSongId >= 0) {
                    int elapsed = getCurrentPosition();
                    int remaining = MIN_PLAY_SECONDS_FOR_COUNT * 1000 - elapsed;
                    if (remaining > 0) {
                        schedulePlayCountDelayed(currentSongId, remaining);
                    }
                    // אם כבר עבר מספיק זמן — כבר נרשם בעבר, לא נרשום שנית
                }
            }
            boolean nowPlaying = player.isPlaying();
            if (callback != null) callback.onPlayStateChanged(nowPlaying);
            updateNotification(nowPlaying);
            broadcastWidgetState(nowPlaying);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void schedulePlayCountDelayed(final long songId, long delayMs) {
        cancelPlayCountTimer();
        playCountRunnable = new Runnable() {
            @Override
            public void run() {
                if (songId == currentSongId && prepared && player != null) {
                    try {
                        if (player.isPlaying()) {
                            new com.musicapp.app.utils.AppPreferences(getApplicationContext())
                                    .recordSongPlayed(songId);
                        }
                    } catch (Exception ignored) {}
                }
            }
        };
        playCountHandler.postDelayed(playCountRunnable, delayMs);
    }

    public void seekForward(int seconds) {
        if (!prepared) return;
        try {
            int pos = player.getCurrentPosition() + seconds * 1000;
            if (pos > player.getDuration()) pos = player.getDuration();
            player.seekTo(pos);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void seekBackward(int seconds) {
        if (!prepared) return;
        try {
            int pos = player.getCurrentPosition() - seconds * 1000;
            if (pos < 0) pos = 0;
            player.seekTo(pos);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public boolean isPlaying() {
        if (!prepared || player == null || playerError) return false;
        try { return player.isPlaying(); } catch (Throwable ignored) { prepared = false; return false; }
    }
    public int getCurrentPosition() {
        if (!prepared || player == null || playerError) return 0;
        try { return player.getCurrentPosition(); } catch (Throwable ignored) { prepared = false; return 0; }
    }
    public int getDuration() {
        if (!prepared || player == null || playerError) return 0;
        try { return player.getDuration(); } catch (Throwable ignored) { prepared = false; return 0; }
    }

    public Song getCurrentSong() {
        if (currentIndex >= 0 && currentIndex < queue.size()) return queue.get(currentIndex);
        return null;
    }

    public int getCurrentIndex() { return currentIndex; }
    public List<Song> getQueue() { return queue; }

    // ===================== עצירה אוטומטית =====================

    private void setupInterruptListeners() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioFocusListener = new AudioManager.OnAudioFocusChangeListener() {
            @Override
            public void onAudioFocusChange(int focusChange) {
                if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                        || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    pauseForInterruption();
                }
            }
        };
        audioManager.requestAudioFocus(audioFocusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                if (state == TelephonyManager.CALL_STATE_RINGING
                        || state == TelephonyManager.CALL_STATE_OFFHOOK) {
                    pauseForInterruption();
                }
            }
        };
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager != null)
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

        bluetoothReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)
                        || android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                    pauseForInterruption();
                }
            }
        };
        IntentFilter btFilter = new IntentFilter();
        btFilter.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED);
        btFilter.addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED);
        registerReceiver(bluetoothReceiver, btFilter);
    }

    private void registerMediaButtonReceiver() {
        // כפתורי אוזניות / bluetooth headset
        mediaButtonReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!Intent.ACTION_MEDIA_BUTTON.equals(intent.getAction())) return;
                android.view.KeyEvent keyEvent = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (keyEvent == null || keyEvent.getAction() != android.view.KeyEvent.ACTION_DOWN) return;
                switch (keyEvent.getKeyCode()) {
                    case android.view.KeyEvent.KEYCODE_HEADSETHOOK:
                    case android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                        togglePlayPause();
                        break;
                    case android.view.KeyEvent.KEYCODE_MEDIA_NEXT:
                        playNext();
                        break;
                    case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                        playPrevious();
                        break;
                }
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_MEDIA_BUTTON);
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        registerReceiver(mediaButtonReceiver, filter);
    }

    private void pauseForInterruption() {
        if (prepared && player.isPlaying()) {
            try {
                player.pause();
                cancelPlayCountTimer();
                pausedByInterruption = true;
                if (callback != null) callback.onPlayStateChanged(false);
                updateNotification(false);
                broadcastWidgetState(false);
            } catch (Exception ignored) {}
        }
    }

    private void teardownInterruptListeners() {
        if (audioManager != null && audioFocusListener != null)
            audioManager.abandonAudioFocus(audioFocusListener);
        if (telephonyManager != null && phoneStateListener != null)
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        if (bluetoothReceiver != null) {
            try { unregisterReceiver(bluetoothReceiver); } catch (Exception ignored) {}
            bluetoothReceiver = null;
        }
        if (mediaButtonReceiver != null) {
            try { unregisterReceiver(mediaButtonReceiver); } catch (Exception ignored) {}
            mediaButtonReceiver = null;
        }
    }

    @Override
    public void onDestroy() {
        teardownInterruptListeners();
        cancelSleepTimer();
        cancelPlayCountTimer();
        if (equalizer != null) {
            try { equalizer.release(); } catch (Exception ignored) {}
            equalizer = null;
        }
        if (player != null) {
            if (prepared) { try { player.stop(); } catch (Exception ignored) {} }
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
