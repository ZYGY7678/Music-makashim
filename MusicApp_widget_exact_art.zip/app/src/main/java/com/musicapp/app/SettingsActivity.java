package com.musicapp.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.musicapp.app.utils.AppPreferences;

public class SettingsActivity extends Activity {

    private AppPreferences prefs;
    private TextView tvFontSizeVal, tvJumpSecondsVal, tvColorPreview;
    private SeekBar sbFontSize, sbJumpSeconds;
    private int[] colorOptions = {
            0xFFFFFFFF, 0xFFFFD700, 0xFF00FF00, 0xFF00FFFF,
            0xFFFF8C00, 0xFFFF69B4, 0xFFADD8E6, 0xFFFFFFAA
    };
    private String[] colorNames = {
            "לבן", "זהב", "ירוק", "תכלת",
            "כתום", "ורוד", "כחול בהיר", "צהוב בהיר"
    };
    private int selectedColorIndex = 0;
    private int focusedItem = 0; // 0=fontSize, 1=jumpSecs, 2=color, 3=save

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = new AppPreferences(this);

        tvFontSizeVal = (TextView) findViewById(R.id.tv_font_size_val);
        tvJumpSecondsVal = (TextView) findViewById(R.id.tv_jump_seconds_val);
        tvColorPreview = (TextView) findViewById(R.id.tv_color_preview);
        sbFontSize = (SeekBar) findViewById(R.id.sb_font_size);
        sbJumpSeconds = (SeekBar) findViewById(R.id.sb_jump_seconds);

        // Font size: 12..24
        sbFontSize.setMax(12);
        sbFontSize.setProgress(prefs.getFontSize() - 12);
        tvFontSizeVal.setText(String.valueOf(prefs.getFontSize()));

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvFontSizeVal.setText(String.valueOf(progress + 12));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Jump seconds: 5..60
        sbJumpSeconds.setMax(55);
        sbJumpSeconds.setProgress(prefs.getJumpSeconds() - 5);
        tvJumpSecondsVal.setText(String.valueOf(prefs.getJumpSeconds()));

        sbJumpSeconds.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvJumpSecondsVal.setText(String.valueOf(progress + 5));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Find current color
        int currentColor = prefs.getFontColor();
        for (int i = 0; i < colorOptions.length; i++) {
            if (colorOptions[i] == currentColor) { selectedColorIndex = i; break; }
        }
        updateColorPreview();

        Button btnSave = (Button) findViewById(R.id.btn_save);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { saveAndExit(); }
        });

        Button btnColorPrev = (Button) findViewById(R.id.btn_color_prev);
        Button btnColorNext = (Button) findViewById(R.id.btn_color_next);
        btnColorPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { changeColor(-1); }
        });
        btnColorNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { changeColor(1); }
        });
    }

    private void changeColor(int dir) {
        selectedColorIndex = (selectedColorIndex + dir + colorOptions.length) % colorOptions.length;
        updateColorPreview();
    }

    private void updateColorPreview() {
        tvColorPreview.setTextColor(colorOptions[selectedColorIndex]);
        tvColorPreview.setText(colorNames[selectedColorIndex]);
    }

    private void saveAndExit() {
        prefs.setFontSize(sbFontSize.getProgress() + 12);
        prefs.setJumpSeconds(sbJumpSeconds.getProgress() + 5);
        prefs.setFontColor(colorOptions[selectedColorIndex]);
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (focusedItem > 0) { focusedItem--; updateFocus(); }
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (focusedItem < 3) { focusedItem++; updateFocus(); }
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                adjustFocusedItem(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                adjustFocusedItem(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (focusedItem == 3) saveAndExit();
                return true;
            case KeyEvent.KEYCODE_BACK:
                finish();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void updateFocus() {
        // highlight focused item visually
        View[] items = {
                sbFontSize,
                sbJumpSeconds,
                tvColorPreview,
                findViewById(R.id.btn_save)
        };
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null)
                items[i].setBackgroundColor(i == focusedItem ? 0xFF1A3A5C : 0x00000000);
        }
    }

    private void adjustFocusedItem(int dir) {
        if (focusedItem == 0) {
            int p = sbFontSize.getProgress() + dir;
            if (p >= 0 && p <= 12) {
                sbFontSize.setProgress(p);
                tvFontSizeVal.setText(String.valueOf(p + 12));
            }
        } else if (focusedItem == 1) {
            int p = sbJumpSeconds.getProgress() + dir * 5;
            if (p >= 0 && p <= 55) {
                sbJumpSeconds.setProgress(p);
                tvJumpSecondsVal.setText(String.valueOf(p + 5));
            }
        } else if (focusedItem == 2) {
            changeColor(dir);
        }
    }
}
