package com.musicapp.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class AppPreferences {
    private static final String PREF_NAME = "MusicAppPrefs";
    private static final String KEY_FONT_SIZE = "font_size";
    private static final String KEY_FONT_COLOR = "font_color";
    private static final String KEY_JUMP_SECONDS = "jump_seconds";
    private static final String KEY_FAVORITES = "favorites";
    private static final String KEY_PLAYLIST_NAMES = "playlist_names";
    private static final String KEY_PLAYLIST_PREFIX = "playlist_";

    private SharedPreferences prefs;

    public AppPreferences(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public int getFontSize() {
        return prefs.getInt(KEY_FONT_SIZE, 16);
    }

    public void setFontSize(int size) {
        prefs.edit().putInt(KEY_FONT_SIZE, size).apply();
    }

    public int getFontColor() {
        return prefs.getInt(KEY_FONT_COLOR, 0xFFFFFFFF);
    }

    public void setFontColor(int color) {
        prefs.edit().putInt(KEY_FONT_COLOR, color).apply();
    }

    public int getJumpSeconds() {
        return prefs.getInt(KEY_JUMP_SECONDS, 10);
    }

    public void setJumpSeconds(int seconds) {
        prefs.edit().putInt(KEY_JUMP_SECONDS, seconds).apply();
    }

    public Set<String> getFavoriteIds() {
        return prefs.getStringSet(KEY_FAVORITES, new HashSet<String>());
    }

    public void saveFavoriteIds(Set<String> ids) {
        prefs.edit().putStringSet(KEY_FAVORITES, ids).apply();
    }

    public boolean isFavorite(long songId) {
        return getFavoriteIds().contains(String.valueOf(songId));
    }

    public void toggleFavorite(long songId) {
        Set<String> favs = new HashSet<>(getFavoriteIds());
        String id = String.valueOf(songId);
        if (favs.contains(id)) {
            favs.remove(id);
        } else {
            favs.add(id);
        }
        saveFavoriteIds(favs);
    }

    // ===================== PLAYLISTS =====================

    public List<String> getPlaylistNames() {
        Set<String> set = prefs.getStringSet(KEY_PLAYLIST_NAMES, new LinkedHashSet<String>());
        List<String> names = new ArrayList<>(set);
        java.util.Collections.sort(names);
        return names;
    }

    public void createPlaylist(String name) {
        if (name == null || name.trim().isEmpty()) return;
        Set<String> names = new LinkedHashSet<>(prefs.getStringSet(KEY_PLAYLIST_NAMES, new LinkedHashSet<String>()));
        names.add(name.trim());
        prefs.edit().putStringSet(KEY_PLAYLIST_NAMES, names).apply();
    }

    public void deletePlaylist(String name) {
        Set<String> names = new LinkedHashSet<>(prefs.getStringSet(KEY_PLAYLIST_NAMES, new LinkedHashSet<String>()));
        names.remove(name);
        prefs.edit().putStringSet(KEY_PLAYLIST_NAMES, names)
                .remove(KEY_PLAYLIST_PREFIX + name)
                .apply();
    }

    public Set<String> getPlaylistSongIds(String playlistName) {
        return prefs.getStringSet(KEY_PLAYLIST_PREFIX + playlistName, new LinkedHashSet<String>());
    }

    public void addSongToPlaylist(String playlistName, long songId) {
        Set<String> ids = new LinkedHashSet<>(getPlaylistSongIds(playlistName));
        ids.add(String.valueOf(songId));
        prefs.edit().putStringSet(KEY_PLAYLIST_PREFIX + playlistName, ids).apply();
    }

    public void removeSongFromPlaylist(String playlistName, long songId) {
        Set<String> ids = new LinkedHashSet<>(getPlaylistSongIds(playlistName));
        ids.remove(String.valueOf(songId));
        prefs.edit().putStringSet(KEY_PLAYLIST_PREFIX + playlistName, ids).apply();
    }

    // ===================== PLAY TRACKING (נוגן לאחרונה / הכי מושמעים) =====================
    // נשמר כ"id:timestamp" / "id:count" במחרוזת מופרדת בפסיקים, כי SharedPreferences
    // אינו תומך ב-Map ישירות, וכך נשמרת תאימות לאחור עם המבנה הקיים.

    private static final String KEY_LAST_PLAYED = "last_played"; // "id:timestampMillis,id:timestampMillis,..."
    private static final String KEY_PLAY_COUNTS = "play_counts"; // "id:count,id:count,..."

    public void recordSongPlayed(long songId) {
        // עדכון "נוגן לאחרונה"
        java.util.LinkedHashMap<Long, Long> lastPlayed = getLastPlayedMap();
        lastPlayed.remove(songId);
        lastPlayed.put(songId, System.currentTimeMillis());
        // משאירים רק את ה-200 האחרונים כדי לא להעמיס
        while (lastPlayed.size() > 200) {
            Long oldestKey = lastPlayed.keySet().iterator().next();
            lastPlayed.remove(oldestKey);
        }
        saveLastPlayedMap(lastPlayed);

        // עדכון "הכי מושמעים"
        java.util.Map<Long, Integer> counts = getPlayCountsMap();
        Integer current = counts.get(songId);
        counts.put(songId, (current == null ? 0 : current) + 1);
        savePlayCountsMap(counts);
    }

    public java.util.LinkedHashMap<Long, Long> getLastPlayedMap() {
        java.util.LinkedHashMap<Long, Long> map = new java.util.LinkedHashMap<>();
        String raw = prefs.getString(KEY_LAST_PLAYED, "");
        if (raw.isEmpty()) return map;
        for (String entry : raw.split(",")) {
            String[] parts = entry.split(":");
            if (parts.length == 2) {
                try {
                    map.put(Long.parseLong(parts[0]), Long.parseLong(parts[1]));
                } catch (NumberFormatException ignored) {}
            }
        }
        return map;
    }

    private void saveLastPlayedMap(java.util.LinkedHashMap<Long, Long> map) {
        StringBuilder sb = new StringBuilder();
        for (java.util.Map.Entry<Long, Long> e : map.entrySet()) {
            if (sb.length() > 0) sb.append(",");
            sb.append(e.getKey()).append(":").append(e.getValue());
        }
        prefs.edit().putString(KEY_LAST_PLAYED, sb.toString()).apply();
    }

    public java.util.Map<Long, Integer> getPlayCountsMap() {
        java.util.Map<Long, Integer> map = new java.util.HashMap<>();
        String raw = prefs.getString(KEY_PLAY_COUNTS, "");
        if (raw.isEmpty()) return map;
        for (String entry : raw.split(",")) {
            String[] parts = entry.split(":");
            if (parts.length == 2) {
                try {
                    map.put(Long.parseLong(parts[0]), Integer.parseInt(parts[1]));
                } catch (NumberFormatException ignored) {}
            }
        }
        return map;
    }

    private void savePlayCountsMap(java.util.Map<Long, Integer> map) {
        StringBuilder sb = new StringBuilder();
        for (java.util.Map.Entry<Long, Integer> e : map.entrySet()) {
            if (sb.length() > 0) sb.append(",");
            sb.append(e.getKey()).append(":").append(e.getValue());
        }
        prefs.edit().putString(KEY_PLAY_COUNTS, sb.toString()).apply();
    }

    public int getPlayCount(long songId) {
        Integer c = getPlayCountsMap().get(songId);
        return c == null ? 0 : c;
    }

    // ===================== EQUALIZER =====================
    private static final String KEY_EQ_BASS = "eq_bass";
    private static final String KEY_EQ_MID = "eq_mid";
    private static final String KEY_EQ_TREBLE = "eq_treble";
    private static final String KEY_EQ_ENABLED = "eq_enabled";

    public int getEqBass() { return prefs.getInt(KEY_EQ_BASS, 50); }
    public int getEqMid() { return prefs.getInt(KEY_EQ_MID, 50); }
    public int getEqTreble() { return prefs.getInt(KEY_EQ_TREBLE, 50); }
    public boolean isEqEnabled() { return prefs.getBoolean(KEY_EQ_ENABLED, false); }

    public void saveEqSettings(int bass, int mid, int treble, boolean enabled) {
        prefs.edit()
                .putInt(KEY_EQ_BASS, bass)
                .putInt(KEY_EQ_MID, mid)
                .putInt(KEY_EQ_TREBLE, treble)
                .putBoolean(KEY_EQ_ENABLED, enabled)
                .apply();
    }

    // ===================== SLEEP TIMER =====================
    private static final String KEY_SLEEP_TIMER_MINUTES = "sleep_timer_minutes";
    private static final String KEY_SLEEP_TIMER_SONGS = "sleep_timer_songs";

    public int getLastSleepTimerMinutes() { return prefs.getInt(KEY_SLEEP_TIMER_MINUTES, 15); }
    public void setLastSleepTimerMinutes(int minutes) {
        prefs.edit().putInt(KEY_SLEEP_TIMER_MINUTES, minutes).apply();
    }

    public int getLastSleepTimerSongs() { return prefs.getInt(KEY_SLEEP_TIMER_SONGS, 3); }
    public void setLastSleepTimerSongs(int songs) {
        prefs.edit().putInt(KEY_SLEEP_TIMER_SONGS, songs).apply();
    }
}
