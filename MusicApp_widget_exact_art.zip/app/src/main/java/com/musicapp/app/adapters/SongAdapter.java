package com.musicapp.app.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.musicapp.app.R;
import com.musicapp.app.models.Song;
import com.musicapp.app.utils.AppPreferences;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SongAdapter extends ArrayAdapter<Song> {
    private Context context;
    private List<Song> songs;
    private AppPreferences prefs;
    private int focusedPosition = 0;
    private int playingPosition = -1;
    private java.util.Map<Long, Integer> playCounts = null;
    private boolean nativeMode = false;

    // multi-select
    private boolean selectionMode = false;
    private Set<Integer> selectedPositions = new HashSet<>();

    public SongAdapter(Context ctx, List<Song> songs, AppPreferences prefs) {
        this(ctx, songs, prefs, false);
    }

    public SongAdapter(Context ctx, List<Song> songs, AppPreferences prefs, boolean nativeMode) {
        super(ctx, 0, songs);
        this.context = ctx;
        this.songs = songs;
        this.prefs = prefs;
        this.nativeMode = nativeMode;
    }

    /** מסמן איזה שיר ברשימה מתנגן כרגע, כדי לצייר עליו ▶ — בלי קשר למיקוד המקלדת */
    public void setPlayingPosition(int pos) {
        this.playingPosition = pos;
        notifyDataSetChanged();
    }

    /** מפעיל הצגת מספר השמעות בכל שורה (משמש ברשימת "הכי הרבה מושמעים") */
    public void setPlayCounts(java.util.Map<Long, Integer> playCounts) {
        this.playCounts = playCounts;
    }

    public int getFocusedPosition() { return focusedPosition; }
    public void setFocusedPosition(int pos) { this.focusedPosition = pos; }

    // ── Multi-select ──────────────────────────────────────────
    public boolean isSelectionMode() { return selectionMode; }

    public void enterSelectionMode(int firstPos) {
        selectionMode = true;
        selectedPositions.clear();
        selectedPositions.add(firstPos);
        notifyDataSetChanged();
    }

    public void toggleSelection(int pos) {
        if (selectedPositions.contains(pos)) selectedPositions.remove(pos);
        else selectedPositions.add(pos);
        notifyDataSetChanged();
    }

    public void selectAll() {
        for (int i = 0; i < songs.size(); i++) selectedPositions.add(i);
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectionMode = false;
        selectedPositions.clear();
        notifyDataSetChanged();
    }

    public List<Song> getSelectedSongs() {
        List<Song> result = new java.util.ArrayList<>();
        for (int pos : selectedPositions) {
            if (pos >= 0 && pos < songs.size()) result.add(songs.get(pos));
        }
        return result;
    }

    public int getSelectedCount() { return selectedPositions.size(); }
    // ─────────────────────────────────────────────────────────

    public void setFocusedPositionAndRefresh(int pos) {
        this.focusedPosition = pos;
        notifyDataSetChanged();
    }

    public void setFocusedPositionAndScrollRefresh(int pos, ListView lv) {
        this.focusedPosition = pos;
        if (lv != null) lv.setSelection(pos);
        notifyDataSetChanged();
    }

    /**
     * הזזת סמן — קודם גוללים בפועל (ensureVisible), ואז מרעננים את כל
     * הרשימה (notifyDataSetChanged) כדי שהצביעה תמיד תהיה נכונה, גם
     * כשהשורות עוברות מחזור (recycle) באמצע גלילה.
     */
    public void moveFocusTo(final int newPos, final ListView lv) {
        if (lv == null) return;
        focusedPosition = newPos;

        ensureVisible(lv, newPos);
        notifyDataSetChanged();
        lv.invalidateViews();
    }

    private void ensureVisible(ListView lv, int pos) {
        int first = lv.getFirstVisiblePosition();
        int last = lv.getLastVisiblePosition();

        if (first == -1 || last == -1) {
            lv.setSelection(pos);
            return;
        }

        if (pos < first) {
            lv.setSelectionFromTop(pos, 0);
        } else if (pos > last) {
            int visibleCount = (last - first) + 1;
            int target = pos - visibleCount + 1;
            if (target < 0) target = 0;
            lv.setSelectionFromTop(target, 0);
        } else {
            lv.setSelection(pos);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_song, parent, false);
        }

        Song song = songs.get(position);
        TextView tvTitle   = convertView.findViewById(R.id.tv_title);
        TextView tvArtist  = convertView.findViewById(R.id.tv_artist);
        TextView tvDuration= convertView.findViewById(R.id.tv_duration);
        TextView tvFav     = convertView.findViewById(R.id.tv_fav);
        TextView tvPlayCount = convertView.findViewById(R.id.tv_play_count);

        tvArtist.setText(song.getArtist() + " — " + song.getAlbum());
        tvDuration.setText(song.getDisplayDuration());
        tvFav.setText(song.isFavorite() ? "★" : "");

        if (tvPlayCount != null) {
            if (playCounts != null) {
                Integer count = playCounts.get(song.getId());
                int c = (count == null) ? 0 : count;
                tvPlayCount.setText("x" + c);
                tvPlayCount.setVisibility(View.VISIBLE);
            } else {
                tvPlayCount.setVisibility(View.GONE);
            }
        }

        int fontSize  = prefs.getFontSize();
        int fontColor = prefs.getFontColor();
        tvTitle.setTextSize(fontSize + 4);
        tvArtist.setTextSize(fontSize - 2);

        if (nativeMode) {
            boolean isPlaying = (position == playingPosition);
            boolean isSelected = selectedPositions.contains(position);

            // רקע: סימון > מתנגן > רגיל
            if (isSelected) {
                convertView.setBackgroundColor(0xFF0D3B66);
            } else {
                convertView.setBackgroundColor(0x00000000);
            }

            // תג סימון
            tvFav.setText(isSelected ? "✔" : (song.isFavorite() ? "★" : ""));
            tvFav.setTextColor(isSelected ? 0xFF4FC3F7 : 0xFFFFD700);

            tvTitle.setTypeface(tvTitle.getTypeface(),
                    isPlaying ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            tvTitle.setText(isPlaying ? ("\u25B6 " + song.getTitle()) : song.getTitle());
            tvTitle.setTextColor(isPlaying ? 0xFFFFD700 : fontColor);
            tvArtist.setTextColor(isPlaying ? 0xFFE0C25C : Color.argb(180,
                    Color.red(fontColor), Color.green(fontColor), Color.blue(fontColor)));
            return convertView;
        }

        if (position == focusedPosition) {
            convertView.setBackgroundColor(0xFF2E6DA4);
            tvTitle.setTextColor(0xFFFFD700);
            tvTitle.setTypeface(tvTitle.getTypeface(), android.graphics.Typeface.BOLD);
            tvTitle.setText("\u25B6 " + song.getTitle());
            tvArtist.setTextColor(0xFFE0C25C);
        } else {
            convertView.setBackgroundColor(0xFF1A1A2E);
            tvTitle.setTypeface(tvTitle.getTypeface(), android.graphics.Typeface.NORMAL);
            tvTitle.setText(song.getTitle());
            tvTitle.setTextColor(fontColor);
            tvArtist.setTextColor(Color.argb(180,
                    Color.red(fontColor), Color.green(fontColor), Color.blue(fontColor)));
        }

        return convertView;
    }
}
