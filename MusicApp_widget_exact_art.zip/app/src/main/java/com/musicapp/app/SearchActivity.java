package com.musicapp.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.musicapp.app.adapters.SongAdapter;
import com.musicapp.app.models.Song;
import com.musicapp.app.utils.AppPreferences;
import com.musicapp.app.utils.MusicLoader;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends Activity {

    private EditText etSearch;
    private ListView lvResults;
    private TextView tvBranding;
    private SongAdapter adapter;
    private List<Song> allSongs;
    private List<Song> results = new ArrayList<>();
    private AppPreferences prefs;
    private boolean listFocused = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        prefs = new AppPreferences(this);
        allSongs = MusicLoader.loadAllSongs(this, prefs);

        etSearch = (EditText) findViewById(R.id.et_search);
        lvResults = (ListView) findViewById(R.id.lv_results);
        tvBranding = (TextView) findViewById(R.id.tv_branding);

        adapter = new SongAdapter(this, results, prefs, true); // nativeMode=true: גלילה ובחירה טבעית של אנדרואיד, בדיוק כמו בהגדרות
        lvResults.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                performSearch(s.toString());
                tvBranding.setVisibility(s.length() > 0 ? View.GONE : View.VISIBLE);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        lvResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                returnSong(position);
            }
        });

        lvResults.setItemsCanFocus(false);
        lvResults.setFocusable(true);
        lvResults.setFocusableInTouchMode(true);

        etSearch.requestFocus();
    }

    private void performSearch(String query) {
        results.clear();
        results.addAll(MusicLoader.searchSongs(allSongs, query));
        adapter.notifyDataSetChanged();
        listFocused = false;
    }

    private void returnSong(int position) {
        if (position < 0 || position >= results.size()) return;
        Intent result = new Intent();
        result.putExtra("song_id", results.get(position).getId());

        // מעבירים את כל מזהי תוצאות החיפוש, כדי שהתור יוקם מהן ולא מכל הספרייה
        long[] resultIds = new long[results.size()];
        for (int i = 0; i < results.size(); i++) {
            resultIds[i] = results.get(i).getId();
        }
        result.putExtra("search_result_ids", resultIds);
        result.putExtra("selected_index", position);

        setResult(RESULT_OK, result);
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (!listFocused && !results.isEmpty()) {
                    listFocused = true;
                    etSearch.clearFocus();
                    lvResults.requestFocus();
                    lvResults.setSelection(0);
                    return true;
                } else if (listFocused) {
                    // מעבירים את האירוע ל-ListView עצמו - זה נותן גלילה ובחירה
                    // טבעית של אנדרואיד, בדיוק כמו ברשימות בהגדרות המכשיר.
                    return lvResults.onKeyDown(keyCode, event);
                }
                return true;

            case KeyEvent.KEYCODE_DPAD_UP:
                if (listFocused) {
                    if (lvResults.getSelectedItemPosition() <= 0) {
                        listFocused = false;
                        etSearch.requestFocus();
                        return true;
                    }
                    return lvResults.onKeyDown(keyCode, event);
                }
                break;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (listFocused) {
                    int pos = lvResults.getSelectedItemPosition();
                    if (pos >= 0) returnSong(pos);
                    return true;
                }
                break;

            case KeyEvent.KEYCODE_BACK:
                if (listFocused) {
                    listFocused = false;
                    etSearch.requestFocus();
                } else {
                    finish();
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
