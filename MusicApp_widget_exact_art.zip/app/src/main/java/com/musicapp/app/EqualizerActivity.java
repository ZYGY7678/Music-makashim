package com.musicapp.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.musicapp.app.service.MusicService;
import com.musicapp.app.utils.AppPreferences;

public class EqualizerActivity extends Activity {

    private AppPreferences prefs;
    private SeekBar sbBass, sbMid, sbTreble;
    private TextView tvBassVal, tvMidVal, tvTrebleVal, tvEnabledVal;
    private View rowEnabled, rowBass, rowMid, rowTreble;
    private Button btnReset;

    private boolean eqEnabled;
    private int focusedItem = 0; // 0=enabled, 1=bass, 2=mid, 3=treble, 4=reset

    private MusicService musicService;
    private boolean serviceBound = false;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            serviceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equalizer);
        prefs = new AppPreferences(this);

        rowEnabled = findViewById(R.id.row_eq_enabled);
        rowBass = findViewById(R.id.row_eq_bass);
        rowMid = findViewById(R.id.row_eq_mid);
        rowTreble = findViewById(R.id.row_eq_treble);

        tvEnabledVal = (TextView) findViewById(R.id.tv_eq_enabled_val);
        tvBassVal = (TextView) findViewById(R.id.tv_eq_bass_val);
        tvMidVal = (TextView) findViewById(R.id.tv_eq_mid_val);
        tvTrebleVal = (TextView) findViewById(R.id.tv_eq_treble_val);

        sbBass = (SeekBar) findViewById(R.id.sb_eq_bass);
        sbMid = (SeekBar) findViewById(R.id.sb_eq_mid);
        sbTreble = (SeekBar) findViewById(R.id.sb_eq_treble);

        btnReset = (Button) findViewById(R.id.btn_eq_reset);

        eqEnabled = prefs.isEqEnabled();
        sbBass.setProgress(prefs.getEqBass());
        sbMid.setProgress(prefs.getEqMid());
        sbTreble.setProgress(prefs.getEqTreble());
        updateAllLabels();

        sbBass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvBassVal.setText(String.valueOf(progress));
                if (fromUser) applyLive();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { saveSettings(); }
        });
        sbMid.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvMidVal.setText(String.valueOf(progress));
                if (fromUser) applyLive();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { saveSettings(); }
        });
        sbTreble.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvTrebleVal.setText(String.valueOf(progress));
                if (fromUser) applyLive();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { saveSettings(); }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { resetDefaults(); }
        });

        updateFocus();

        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
    }

    private void updateAllLabels() {
        tvEnabledVal.setText(eqEnabled ? "פעיל" : "כבוי");
        tvEnabledVal.setTextColor(eqEnabled ? 0xFF00FF66 : 0xFFFFD700);
        tvBassVal.setText(String.valueOf(sbBass.getProgress()));
        tvMidVal.setText(String.valueOf(sbMid.getProgress()));
        tvTrebleVal.setText(String.valueOf(sbTreble.getProgress()));
    }

    private void toggleEnabled() {
        eqEnabled = !eqEnabled;
        updateAllLabels();
        saveSettings();
        if (serviceBound) musicService.setEqualizerEnabled(eqEnabled);
    }

    private void applyLive() {
        if (serviceBound) {
            musicService.applyEqualizerLevels(sbBass.getProgress(), sbMid.getProgress(), sbTreble.getProgress());
        }
    }

    private void saveSettings() {
        prefs.saveEqSettings(sbBass.getProgress(), sbMid.getProgress(), sbTreble.getProgress(), eqEnabled);
        applyLive();
    }

    private void resetDefaults() {
        eqEnabled = false;
        sbBass.setProgress(50);
        sbMid.setProgress(50);
        sbTreble.setProgress(50);
        updateAllLabels();
        saveSettings();
        if (serviceBound) musicService.setEqualizerEnabled(false);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (focusedItem > 0) { focusedItem--; updateFocus(); }
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (focusedItem < 4) { focusedItem++; updateFocus(); }
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                adjustFocusedItem(-1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                adjustFocusedItem(1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                activateFocusedItem();
                return true;
            case KeyEvent.KEYCODE_BACK:
                finish();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void updateFocus() {
        View[] items = { rowEnabled, rowBass, rowMid, rowTreble, btnReset };
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null) {
                items[i].setBackgroundColor(i == focusedItem ? 0xFF1A3A5C : 0x00000000);
            }
        }
    }

    private void adjustFocusedItem(int dir) {
        switch (focusedItem) {
            case 0:
                toggleEnabled();
                break;
            case 1: {
                int p = sbBass.getProgress() + dir * 5;
                if (p >= 0 && p <= 100) { sbBass.setProgress(p); saveSettings(); }
                break;
            }
            case 2: {
                int p = sbMid.getProgress() + dir * 5;
                if (p >= 0 && p <= 100) { sbMid.setProgress(p); saveSettings(); }
                break;
            }
            case 3: {
                int p = sbTreble.getProgress() + dir * 5;
                if (p >= 0 && p <= 100) { sbTreble.setProgress(p); saveSettings(); }
                break;
            }
        }
    }

    private void activateFocusedItem() {
        if (focusedItem == 0) {
            toggleEnabled();
        } else if (focusedItem == 4) {
            resetDefaults();
        }
    }
}
