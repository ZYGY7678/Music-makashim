package com.musicapp.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import com.musicapp.app.adapters.SongAdapter;
import com.musicapp.app.adapters.StringAdapter;
import com.musicapp.app.models.Song;
import com.musicapp.app.service.MusicService;
import com.musicapp.app.utils.AppPreferences;
import com.musicapp.app.utils.MusicLoader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity implements MusicService.MusicCallback {

    // ===================== טאבים (7) =====================
    private static final int TAB_CENTRAL = 0;
    private static final int TAB_GENRES = 1;
    private static final int TAB_ARTISTS = 2;
    private static final int TAB_ALBUMS = 3;
    private static final int TAB_FOLDERS = 4;
    private static final int TAB_NOW_PLAYING = 5;
    private static final int TAB_QUEUE = 6;

    private static final int TAB_COUNT = 7;
    private static final String[] TAB_LABELS = {
        "📁", "🎼", "🎤", "💿", "📂", "▶️", "📋"
    };
    private static final String[] TAB_NAMES = {
        "ראשי", "ז'אנר", "אמן", "אלבום", "תיקיה", "מתנגן", "תור"
    };
    private static final int[] TAB_FRAME_IDS = {
        R.id.tab_central, R.id.tab_genres, R.id.tab_artists,
        R.id.tab_albums, R.id.tab_folders, R.id.tab_now_playing, R.id.tab_queue
    };
    private static final int[] TAB_LABEL_IDS = {
        R.id.tab_label_0, R.id.tab_label_1, R.id.tab_label_2,
        R.id.tab_label_3, R.id.tab_label_4, R.id.tab_label_5, R.id.tab_label_6
    };
    private static final int[] TAB_NAME_IDS = {
        R.id.tab_name_0, R.id.tab_name_1, R.id.tab_name_2,
        R.id.tab_name_3, R.id.tab_name_4, R.id.tab_name_5, R.id.tab_name_6
    };
    private static final int[] TAB_CELL_IDS = {
        R.id.tab_cell_0, R.id.tab_cell_1, R.id.tab_cell_2,
        R.id.tab_cell_3, R.id.tab_cell_4, R.id.tab_cell_5, R.id.tab_cell_6
    };
    private FrameLayout[] tabFrames = new FrameLayout[TAB_COUNT];
    private TextView[] tabLabelViews = new TextView[TAB_COUNT];
    private TextView[] tabNameViews = new TextView[TAB_COUNT];
    private android.view.View[] tabCellViews = new android.view.View[TAB_COUNT];
    private int currentTab = 0;

    // ===================== טור א' - מרכזי: 6 אופציות =====================
    private static final int CENTRAL_ALL_SONGS = 0;
    private static final int CENTRAL_FAVORITES = 1;
    private static final int CENTRAL_RECENTLY_ADDED = 2;
    private static final int CENTRAL_RECENTLY_PLAYED = 3;
    private static final int CENTRAL_MOST_PLAYED = 4;
    private static final int CENTRAL_PLAYLISTS = 5;
    private static final String[] CENTRAL_MENU_LABELS = {
        "🎵 כל השירים", "⭐ מועדפים", "🆕 נוספו לאחרונה",
        "⏱️ נוגן לאחרונה", "🔥 הכי הרבה מושמעים", "📑 פלייליסטים"
    };
    private Integer centralSelectedOption = null;
    private StringAdapter centralMenuAdapter;
    private List<String> centralMenuItems = new ArrayList<>();

    private ListView lvCentralMenu, lvMusic, lvGenres, lvGenreSongs, lvArtists, lvArtistSongs,
            lvAlbums, lvFolders, lvFolderSongs, lvQueue, lvPlaylists, lvPlaylistSongs;
    private SongAdapter musicAdapter, queueAdapter, genreSongsAdapter, artistSongsAdapter, playlistSongsAdapter;
    private StringAdapter genreAdapter, artistAdapter, albumAdapter, playlistAdapter, folderAdapter;
    private TextView tvSubScreenTitle;

    private List<Song> allSongs = new ArrayList<>();
    private List<Song> favSongs = new ArrayList<>();
    private List<Song> recentlyAddedSongs = new ArrayList<>();
    private List<Song> recentlyPlayedSongs = new ArrayList<>();
    private List<Song> mostPlayedSongs = new ArrayList<>();
    private List<Song> currentGenreSongs = new ArrayList<>();
    private List<Song> currentArtistSongs = new ArrayList<>();
    private List<Song> currentPlaylistSongs = new ArrayList<>();
    private List<String> genres = new ArrayList<>();
    private List<String> artists = new ArrayList<>();
    private List<String> albums = new ArrayList<>();
    private List<String> folders = new ArrayList<>();
    private List<String> playlistNames = new ArrayList<>();
    private String openFolderName = null;
    private List<Song> currentFolderSongs = new ArrayList<>();
    private SongAdapter folderSongsAdapter;

    // ===================== עץ תיקיות (כמו סייר קבצים) =====================
    private String folderRootPath = "/";
    private String currentFolderPath = "/";
    private List<String> currentSubfolderNames = new ArrayList<>(); // שמות תתי-תיקיות גולמיים (בלי אייקון), לפי סדר התצוגה
    private boolean folderUpEntryVisible = false;
    private boolean folderFilesEntryVisible = false;
    private String openGenreName = null;
    private String openArtistName = null;
    private String openPlaylistName = null;

    private List<Song> activeCentralSongs = null;
    private SongAdapter activeCentralAdapter = null;

    private TextView tvNowTitle, tvNowArtist, tvNowAlbum, tvNowTime;
    private android.widget.ProgressBar pbNowProgress;
    private ImageView ivNowBackground;

    private MusicService musicService;
    private boolean serviceBound = false;

    private long lastPlayTime = 0;

    private AppPreferences prefs;
    private Handler progressHandler = new Handler();
    private Runnable progressRunnable;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            musicService.setCallback(MainActivity.this);
            serviceBound = true;
            startProgressUpdater();
            restoreLastPlayedIfEmpty();
            // טיפול ב-URI שממתין (פתח באמצעות)
            if (pendingOpenUri != null) {
                playUriDirectly(pendingOpenUri);
                pendingOpenUri = null;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    /**
     * אם נכנסים לנגן ואין שיר נוכחי טעון (השירות עלה לראשונה, בלי שום נגינה),
     * טוענים את השיר האחרון ששמעו במצב מושהה - כך שמסך הנגן הראשי לא ריק
     * וניתן להמשיך נגינה בלחיצה אחת.
     */
    private void restoreLastPlayedIfEmpty() {
        if (!serviceBound) return;
        if (musicService.getCurrentSong() != null) return; // יש כבר שיר טעון/מתנגן - לא נוגעים
        if (recentlyPlayedSongs == null || recentlyPlayedSongs.isEmpty()) return; // אין היסטוריה

        Song lastSong = recentlyPlayedSongs.get(0);
        int indexInLibrary = findSongIndexById(allSongs, lastSong.getId());
        if (indexInLibrary < 0) return; // השיר לא קיים יותר בספרייה

        musicService.loadQueuePaused(allSongs, indexInLibrary);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new AppPreferences(this);
        setupTabs();
        setupNowPlayingViews();
        loadMusic();
        showCentralMenu();

        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        startService(intent);

        // טיפול בפתיחת קובץ אודיו מבחוץ (פתח באמצעות)
        handleOpenWithIntent(getIntent());
    }

    /** פתח שיר שהועבר מבחוץ (פתח באמצעות) */
    private Uri pendingOpenUri = null;

    private void handleOpenWithIntent(Intent incoming) {
        if (incoming == null) return;
        String action = incoming.getAction();
        if (!Intent.ACTION_VIEW.equals(action)) return;
        Uri uri = incoming.getData();
        if (uri == null) return;

        if (serviceBound) {
            playUriDirectly(uri);
        } else {
            // השירות עוד לא מוכן – נשמור ונפעיל כשיתחבר
            pendingOpenUri = uri;
        }
    }

    private void playUriDirectly(Uri uri) {
        try {
            // ננסה למצוא את השיר ברשימה לפי URI
            String path = uri.getPath();
            if (path != null) {
                for (int i = 0; i < allSongs.size(); i++) {
                    Song s = allSongs.get(i);
                    if (path.equals(s.getPath())) {
                        playSongFromList(allSongs, i);
                        showTab(TAB_NOW_PLAYING);
                        currentTab = TAB_NOW_PLAYING;
                        return;
                    }
                }
            }
            // לא נמצא ברשימה – השמע ישירות דרך Uri
            if (serviceBound) {
                musicService.playFromUri(uri);
                showTab(TAB_NOW_PLAYING);
                currentTab = TAB_NOW_PLAYING;
            }
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "שגיאה בפתיחת הקובץ", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void setupTabs() {
        for (int i = 0; i < TAB_COUNT; i++) {
            tabFrames[i] = (FrameLayout) findViewById(TAB_FRAME_IDS[i]);
            tabLabelViews[i] = (TextView) findViewById(TAB_LABEL_IDS[i]);
            tabLabelViews[i].setText(TAB_LABELS[i]);
            tabLabelViews[i].setFocusable(false);
            tabNameViews[i] = (TextView) findViewById(TAB_NAME_IDS[i]);
            tabNameViews[i].setText(TAB_NAMES[i]);
            tabCellViews[i] = findViewById(TAB_CELL_IDS[i]);
        }
        showTab(0);

        tvSubScreenTitle = (TextView) findViewById(R.id.tv_sub_screen_title);

        lvCentralMenu = (ListView) findViewById(R.id.lv_central_menu);
        lvMusic = (ListView) findViewById(R.id.lv_music);
        lvGenres = (ListView) findViewById(R.id.lv_genres);
        lvGenreSongs = (ListView) findViewById(R.id.lv_genre_songs);
        lvArtists = (ListView) findViewById(R.id.lv_artists);
        lvArtistSongs = (ListView) findViewById(R.id.lv_artist_songs);
        lvAlbums = (ListView) findViewById(R.id.lv_albums);
        lvFolders = (ListView) findViewById(R.id.lv_folders);
        lvFolderSongs = (ListView) findViewById(R.id.lv_folder_songs);
        lvQueue = (ListView) findViewById(R.id.lv_queue);
        lvPlaylists = (ListView) findViewById(R.id.lv_playlists);
        lvPlaylistSongs = (ListView) findViewById(R.id.lv_playlist_songs);

        setupListClickListeners();
    }

    private void showTab(int index) {
        for (int i = 0; i < TAB_COUNT; i++) {
            tabFrames[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            boolean active = (i == index);
            // רקע כחול לטאב הפעיל
            tabCellViews[i].setBackgroundColor(active ? 0xFF1A3A6A : 0x00000000);
            tabLabelViews[i].setTextColor(active ? 0xFFFFD700 : 0xFF888899);
            tabNameViews[i].setTextColor(active ? 0xFFFFD700 : 0xFF888899);
        }
    }

    /**
     * מחבר לרשימת שירים touch-listener שמזהה לחיצה ארוכה של 350ms בלבד
     * (במקום 500ms של אנדרואיד), ומבטל את ה-click הרגיל כשהלחיצה הארוכה
     * זוהתה — כך שהשיר לא יופעל בטעות.
     */
    private void attachSongLongPress(final ListView lv,
                                     final SongAdapterProvider adapterProvider,
                                     final SongListProvider listProvider) {
        // חשוב: המכשיר הוא טלפון מקשים ללא מסך מגע! לכן אי אפשר להסתמך על
        // אירועי מגע (MotionEvent) כדי לזהות "לחיצה ארוכה" - הם פשוט לא קורים
        // כשמשתמשים בלחצנים פיזיים. אנדרואיד יודע, מובנה, לזהות החזקה ארוכה
        // של מקש התפריט/OK על שורה שיש לה פוקוס (בדיוק כמו לחיצה ארוכה במגע)
        // ומפעיל את ה-OnItemLongClickListener הרגיל - לכן זה הדרך הנכונה
        // והאמינה גם למגע וגם למקשים פיזיים.
        lv.setOnTouchListener(null);
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                SongAdapter adapter = adapterProvider.get();
                List<Song> list = listProvider.get();
                if (adapter != null && list != null && position >= 0 && position < list.size()) {
                    onSongLongClick(adapter, list, position);
                    return true;
                }
                return false;
            }
        });
    }

    interface SongAdapterProvider { SongAdapter get(); }
    interface SongListProvider    { List<Song> get(); }

    private void setupListClickListeners() {
        lvCentralMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openCentralOption(position);
            }
        });

        lvMusic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (activeCentralAdapter != null && activeCentralAdapter.isSelectionMode()) {
                    activeCentralAdapter.toggleSelection(position);
                    return;
                }
                if (activeCentralAdapter != null) activeCentralAdapter.setFocusedPosition(position);
                playSongFromList(activeCentralSongs, position);
            }
        });
        attachSongLongPress(lvMusic,
                new SongAdapterProvider() { @Override public SongAdapter get() { return activeCentralAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  { return activeCentralSongs;   } });

        lvPlaylists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openPlaylist(playlistNames.get(position));
            }
        });
        lvPlaylists.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < playlistNames.size()) {
                    showPlaylistMenu(playlistNames.get(position));
                }
                return true;
            }
        });
        lvPlaylistSongs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (playlistSongsAdapter != null && playlistSongsAdapter.isSelectionMode()) {
                    playlistSongsAdapter.toggleSelection(position);
                    return;
                }
                playlistSongsAdapter.setFocusedPosition(position);
                playSongFromList(currentPlaylistSongs, position);
            }
        });
        attachSongLongPress(lvPlaylistSongs,
                new SongAdapterProvider() { @Override public SongAdapter get() { return playlistSongsAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  { return currentPlaylistSongs; } });

        lvFolders.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handleFolderTreeItemClick(position);
            }
        });
        lvFolderSongs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (folderSongsAdapter != null && folderSongsAdapter.isSelectionMode()) {
                    folderSongsAdapter.toggleSelection(position);
                    return;
                }
                if (folderSongsAdapter != null) folderSongsAdapter.setFocusedPosition(position);
                playSongFromList(currentFolderSongs, position);
            }
        });
        attachSongLongPress(lvFolderSongs,
                new SongAdapterProvider() { @Override public SongAdapter get() { return folderSongsAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  { return currentFolderSongs; } });

        lvGenres.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openGenre(genres.get(position));
            }
        });
        lvGenreSongs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (genreSongsAdapter != null && genreSongsAdapter.isSelectionMode()) {
                    genreSongsAdapter.toggleSelection(position);
                    return;
                }
                genreSongsAdapter.setFocusedPosition(position);
                playSongFromList(currentGenreSongs, position);
            }
        });
        attachSongLongPress(lvGenreSongs,
                new SongAdapterProvider() { @Override public SongAdapter get() { return genreSongsAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  { return currentGenreSongs;  } });

        lvArtists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openArtist(artists.get(position));
            }
        });
        lvArtistSongs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (artistSongsAdapter != null && artistSongsAdapter.isSelectionMode()) {
                    artistSongsAdapter.toggleSelection(position);
                    return;
                }
                artistSongsAdapter.setFocusedPosition(position);
                playSongFromList(currentArtistSongs, position);
            }
        });
        attachSongLongPress(lvArtistSongs,
                new SongAdapterProvider() { @Override public SongAdapter get() { return artistSongsAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  { return currentArtistSongs;  } });

        lvAlbums.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String album = albums.get(position);
                List<Song> albumSongs = MusicLoader.getSongsByAlbum(allSongs, album);
                playSongFromList(albumSongs, 0);
            }
        });

        lvQueue.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (queueAdapter != null && queueAdapter.isSelectionMode()) {
                    queueAdapter.toggleSelection(position);
                    return;
                }
                if (serviceBound) {
                    musicService.playSongAtIndex(position);
                    switchToTab(TAB_NOW_PLAYING);
                }
            }
        });
        attachSongLongPress(lvQueue,
                new SongAdapterProvider() { @Override public SongAdapter get() { return queueAdapter; } },
                new SongListProvider()    { @Override public List<Song> get()  {
                    return serviceBound ? musicService.getQueue() : new ArrayList<Song>();
                } });
    }

    private void setupNowPlayingViews() {
        ivNowBackground = (ImageView) findViewById(R.id.iv_now_background);
        tvNowTitle = (TextView) findViewById(R.id.tv_now_title);
        tvNowArtist = (TextView) findViewById(R.id.tv_now_artist);
        tvNowAlbum = (TextView) findViewById(R.id.tv_now_album);
        tvNowTime = (TextView) findViewById(R.id.tv_now_time);
        pbNowProgress = (android.widget.ProgressBar) findViewById(R.id.pb_now_progress);
    }

    private void loadMusic() {
        allSongs = MusicLoader.loadAllSongs(this, prefs);
        genres = MusicLoader.getGenres(allSongs);
        artists = MusicLoader.getArtists(allSongs);
        albums = MusicLoader.getAlbums(allSongs);

        favSongs = new ArrayList<>();
        for (Song s : allSongs) {
            s.setFavorite(prefs.isFavorite(s.getId()));
            if (s.isFavorite()) favSongs.add(s);
        }

        recomputeRecentlyAdded();
        recomputeRecentlyPlayed();
        recomputeMostPlayed();

        genreAdapter = new StringAdapter(this, genres, prefs, true);
        lvGenres.setAdapter(genreAdapter);

        artistAdapter = new StringAdapter(this, artists, prefs, true);
        lvArtists.setAdapter(artistAdapter);

        albumAdapter = new StringAdapter(this, albums, prefs, true);
        lvAlbums.setAdapter(albumAdapter);

        playlistNames = prefs.getPlaylistNames();
        playlistAdapter = new StringAdapter(this, playlistNames, prefs, true);
        lvPlaylists.setAdapter(playlistAdapter);

        folderRootPath = MusicLoader.getFolderTreeRoot(allSongs);
        currentFolderPath = folderRootPath;
        refreshFolderTreeView();
    }

    /**
     * בונה מחדש את רשימת התיקייה הנוכחית בעץ: תת-תיקיות (📁), ואם יש
     * שירים ישירות בתיקייה זו - שורת "קבצים בתיקייה זו" בסוף, בדיוק
     * כמו רשימת תיקיות בסייר קבצים רגיל.
     */
    private void refreshFolderTreeView() {
        currentSubfolderNames = MusicLoader.getSubfolders(allSongs, currentFolderPath);
        List<Song> filesHere = MusicLoader.getSongsInFolderPath(allSongs, currentFolderPath);

        folderUpEntryVisible = !currentFolderPath.equals(folderRootPath);
        folderFilesEntryVisible = !filesHere.isEmpty();

        folders = new ArrayList<>();
        if (folderUpEntryVisible) {
            folders.add("⬆️ .. (תיקייה למעלה)");
        }
        for (String name : currentSubfolderNames) {
            folders.add("📁 " + name);
        }
        if (folderFilesEntryVisible) {
            folders.add("🎵 קבצים בתיקייה זו (" + filesHere.size() + ")");
        }
        if (folders.isEmpty()) {
            folders.add("(תיקייה ריקה)");
        }

        if (folderAdapter == null) {
            folderAdapter = new StringAdapter(this, folders, prefs, true);
            lvFolders.setAdapter(folderAdapter);
        } else {
            folderAdapter.clear();
            folderAdapter.addAll(folders);
            folderAdapter.notifyDataSetChanged();
        }
    }

    /** מטפל בבחירת שורה ברשימת התיקייה הנוכחית (עלייה/כניסה לתת-תיקייה/הצגת קבצים) */
    private void handleFolderTreeItemClick(int position) {
        int idx = position;
        if (folderUpEntryVisible) {
            if (idx == 0) {
                goUpFolder();
                return;
            }
            idx--;
        }
        if (idx < currentSubfolderNames.size()) {
            enterSubfolder(currentSubfolderNames.get(idx));
            return;
        }
        if (folderFilesEntryVisible) {
            openFolder(currentFolderPath);
        }
    }

    private void enterSubfolder(String name) {
        String base = currentFolderPath.endsWith("/") ? currentFolderPath : currentFolderPath + "/";
        currentFolderPath = base + name;
        refreshFolderTreeView();
        lvFolders.post(new Runnable() {
            @Override public void run() { lvFolders.setSelection(0); lvFolders.requestFocus(); }
        });
    }

    /** עולה תיקייה אחת למעלה. מחזיר false אם כבר בשורש (אין לאן לעלות) */
    private boolean goUpFolder() {
        String parent = MusicLoader.getParentFolderPath(currentFolderPath, folderRootPath);
        if (parent == null) return false;
        currentFolderPath = parent;
        refreshFolderTreeView();
        lvFolders.post(new Runnable() {
            @Override public void run() { lvFolders.setSelection(0); lvFolders.requestFocus(); }
        });
        return true;
    }

    private void recomputeRecentlyAdded() {
        recentlyAddedSongs = new ArrayList<>(allSongs);
        Collections.sort(recentlyAddedSongs, new Comparator<Song>() {
            @Override
            public int compare(Song a, Song b) {
                return Long.compare(b.getDateAdded(), a.getDateAdded());
            }
        });
        if (recentlyAddedSongs.size() > 100) {
            recentlyAddedSongs = new ArrayList<>(recentlyAddedSongs.subList(0, 100));
        }
    }

    private void recomputeRecentlyPlayed() {
        java.util.LinkedHashMap<Long, Long> lastPlayed = prefs.getLastPlayedMap();
        List<Long> ids = new ArrayList<>(lastPlayed.keySet());
        Collections.reverse(ids);
        recentlyPlayedSongs = new ArrayList<>();
        for (Long id : ids) {
            Song s = findSongById(allSongs, id);
            if (s != null) recentlyPlayedSongs.add(s);
        }
    }

    private void recomputeMostPlayed() {
        final java.util.Map<Long, Integer> counts = prefs.getPlayCountsMap();
        final java.util.LinkedHashMap<Long, Long> lastPlayed = prefs.getLastPlayedMap();
        mostPlayedSongs = new ArrayList<>();
        for (Song s : allSongs) {
            Integer c = counts.get(s.getId());
            if (c != null && c > 0) mostPlayedSongs.add(s);
        }
        // מיון ראשוני לפי מספר השמעות (יורד), ואחר כך לפי זמן השמעה אחרון (יורד) לשוויון
        Collections.sort(mostPlayedSongs, new Comparator<Song>() {
            @Override
            public int compare(Song a, Song b) {
                int ca = counts.get(a.getId()) == null ? 0 : counts.get(a.getId());
                int cb = counts.get(b.getId()) == null ? 0 : counts.get(b.getId());
                if (cb != ca) return Integer.compare(cb, ca);
                // שוויון — מי שהושמע לאחרונה קודם
                long la = lastPlayed.containsKey(a.getId()) ? lastPlayed.get(a.getId()) : 0L;
                long lb = lastPlayed.containsKey(b.getId()) ? lastPlayed.get(b.getId()) : 0L;
                return Long.compare(lb, la);
            }
        });
    }

    private Song findSongById(List<Song> songs, long id) {
        for (Song s : songs) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    private int findSongIndexById(List<Song> songs, long id) {
        for (int i = 0; i < songs.size(); i++) {
            if (songs.get(i).getId() == id) return i;
        }
        return -1;
    }

    // ===================== טור א' - ניווט מרכזי =====================

    private void showCentralMenu() {
        centralSelectedOption = null;
        centralMenuItems = new ArrayList<>();
        for (String label : CENTRAL_MENU_LABELS) centralMenuItems.add(label);
        centralMenuAdapter = new StringAdapter(this, centralMenuItems, prefs, true);
        lvCentralMenu.setAdapter(centralMenuAdapter);

        lvCentralMenu.setVisibility(View.VISIBLE);
        lvMusic.setVisibility(View.GONE);
        lvPlaylists.setVisibility(View.GONE);
        lvPlaylistSongs.setVisibility(View.GONE);
        tvSubScreenTitle.setVisibility(View.GONE);
        openPlaylistName = null;
        activeCentralSongs = null;
        activeCentralAdapter = null;
        lvCentralMenu.post(new Runnable() { @Override public void run() { lvCentralMenu.requestFocus(); } });
    }

    private void openCentralOption(int option) {
        centralSelectedOption = option;
        switch (option) {
            case CENTRAL_ALL_SONGS:
                showCentralSongList(allSongs, "🎵 כל השירים");
                break;
            case CENTRAL_FAVORITES:
                showCentralSongList(favSongs, "⭐ מועדפים");
                break;
            case CENTRAL_RECENTLY_ADDED:
                recomputeRecentlyAdded();
                showCentralSongList(recentlyAddedSongs, "🆕 נוספו לאחרונה");
                break;
            case CENTRAL_RECENTLY_PLAYED:
                recomputeRecentlyPlayed();
                showCentralSongList(recentlyPlayedSongs, "⏱️ נוגן לאחרונה");
                break;
            case CENTRAL_MOST_PLAYED:
                recomputeMostPlayed();
                showCentralSongList(mostPlayedSongs, "🔥 הכי הרבה מושמעים");
                if (activeCentralAdapter != null) {
                    activeCentralAdapter.setPlayCounts(prefs.getPlayCountsMap());
                    activeCentralAdapter.notifyDataSetChanged();
                }
                break;
            case CENTRAL_PLAYLISTS:
                showPlaylistsList();
                tvSubScreenTitle.setText("📑 פלייליסטים");
                tvSubScreenTitle.setVisibility(View.VISIBLE);
                lvCentralMenu.setVisibility(View.GONE);
                lvMusic.setVisibility(View.GONE);
                break;
        }
    }

    private void showCentralSongList(List<Song> songs, String title) {
        activeCentralSongs = songs;
        activeCentralAdapter = new SongAdapter(this, songs, prefs, true);
        lvMusic.setAdapter(activeCentralAdapter);

        musicAdapter = activeCentralAdapter;

        tvSubScreenTitle.setText(title);
        tvSubScreenTitle.setVisibility(View.VISIBLE);
        lvCentralMenu.setVisibility(View.GONE);
        lvPlaylists.setVisibility(View.GONE);
        lvPlaylistSongs.setVisibility(View.GONE);
        lvMusic.setVisibility(View.VISIBLE);
        lvMusic.post(new Runnable() { @Override public void run() { lvMusic.requestFocus(); } });
    }

    private boolean handleCentralBack() {
        if (centralSelectedOption == null) return false;

        if (centralSelectedOption == CENTRAL_PLAYLISTS && openPlaylistName != null) {
            showPlaylistsList();
            return true;
        }
        showCentralMenu();
        return true;
    }

    // ===================== טור ב' - ז'אנרים =====================

    private void openGenre(String genre) {
        openGenreName = genre;
        currentGenreSongs = MusicLoader.getSongsByGenre(allSongs, genre);
        genreSongsAdapter = new SongAdapter(this, currentGenreSongs, prefs, true);
        lvGenreSongs.setAdapter(genreSongsAdapter);
        lvGenres.setVisibility(View.GONE);
        lvGenreSongs.setVisibility(View.VISIBLE);
        lvGenreSongs.post(new Runnable() { @Override public void run() { lvGenreSongs.requestFocus(); } });
    }

    private void showGenresList() {
        openGenreName = null;
        lvGenreSongs.setVisibility(View.GONE);
        lvGenres.setVisibility(View.VISIBLE);
        lvGenres.post(new Runnable() { @Override public void run() { lvGenres.requestFocus(); } });
    }

    // ===================== טור ג' - אומנים =====================

    private void openArtist(String artist) {
        openArtistName = artist;
        currentArtistSongs = MusicLoader.getSongsByArtist(allSongs, artist);
        artistSongsAdapter = new SongAdapter(this, currentArtistSongs, prefs, true);
        lvArtistSongs.setAdapter(artistSongsAdapter);
        lvArtists.setVisibility(View.GONE);
        lvArtistSongs.setVisibility(View.VISIBLE);
        lvArtistSongs.post(new Runnable() { @Override public void run() { lvArtistSongs.requestFocus(); } });
    }

    private void showArtistsList() {
        openArtistName = null;
        lvArtistSongs.setVisibility(View.GONE);
        lvArtists.setVisibility(View.VISIBLE);
        lvArtists.post(new Runnable() { @Override public void run() { lvArtists.requestFocus(); } });
    }

    // ===================== טור ה' - תיקיות =====================

    private void openFolder(String folderPath) {
        openFolderName = folderPath;
        currentFolderSongs = MusicLoader.getSongsInFolderPath(allSongs, folderPath);
        folderSongsAdapter = new SongAdapter(this, currentFolderSongs, prefs, true);
        lvFolderSongs.setAdapter(folderSongsAdapter);
        lvFolders.setVisibility(View.GONE);
        lvFolderSongs.setVisibility(View.VISIBLE);
        lvFolderSongs.post(new Runnable() {
            @Override
            public void run() {
                lvFolderSongs.requestFocus();
                if (lvFolderSongs.getSelectedItemPosition() == ListView.INVALID_POSITION
                        && !currentFolderSongs.isEmpty()) {
                    lvFolderSongs.setSelection(0);
                }
            }
        });
    }

    private void showFoldersList() {
        openFolderName = null;
        lvFolderSongs.setVisibility(View.GONE);
        lvFolders.setVisibility(View.VISIBLE);
        lvFolders.post(new Runnable() {
            @Override
            public void run() {
                lvFolders.requestFocus();
            }
        });
    }

    // ===================== פלייליסטים =====================

    private void refreshFavorites() {
        int savedPos = (centralSelectedOption != null && centralSelectedOption == CENTRAL_FAVORITES)
                ? readSelected(lvMusic, favSongs.size()) : 0;
        if (savedPos < 0) savedPos = 0;
        favSongs.clear();
        for (Song s : allSongs) {
            s.setFavorite(prefs.isFavorite(s.getId()));
            if (s.isFavorite()) favSongs.add(s);
        }
        if (centralSelectedOption != null && centralSelectedOption == CENTRAL_FAVORITES) {
            int clampedPos = (savedPos < favSongs.size()) ? savedPos : 0;
            if (activeCentralAdapter != null) {
                activeCentralAdapter.notifyDataSetChanged();
                lvMusic.setSelection(clampedPos);
            }
        }
    }

    private void refreshCurrentTab() {
        switch (currentTab) {
            case TAB_CENTRAL:
                if (centralSelectedOption != null && centralSelectedOption == CENTRAL_FAVORITES) {
                    refreshFavorites();
                } else if (centralSelectedOption != null && centralSelectedOption == CENTRAL_PLAYLISTS) {
                    refreshPlaylistsTab();
                }
                break;
            case TAB_QUEUE:
                if (serviceBound && queueAdapter == null) {
                    queueAdapter = new SongAdapter(this, musicService.getQueue(), prefs, true);
                    lvQueue.setAdapter(queueAdapter);
                } else if (queueAdapter != null) {
                    queueAdapter.notifyDataSetChanged();
                }
                break;
        }
    }

    private void refreshPlaylistsTab() {
        if (openPlaylistName != null) {
            if (!prefs.getPlaylistNames().contains(openPlaylistName)) {
                showPlaylistsList();
                return;
            }
            refreshOpenPlaylistSongs();
        } else {
            playlistNames = prefs.getPlaylistNames();
            if (playlistAdapter != null) {
                int saved = readSelected(lvPlaylists, playlistNames.size());
                if (saved < 0) saved = 0;
                playlistAdapter = new StringAdapter(this, playlistNames, prefs, true);
                int clamped = (saved < playlistNames.size()) ? saved : 0;
                lvPlaylists.setAdapter(playlistAdapter);
                lvPlaylists.setSelection(clamped);
            }
        }
    }

    private void openPlaylist(String name) {
        openPlaylistName = name;
        refreshOpenPlaylistSongs();
        lvPlaylists.setVisibility(View.GONE);
        lvPlaylistSongs.setVisibility(View.VISIBLE);
        lvPlaylistSongs.post(new Runnable() { @Override public void run() { lvPlaylistSongs.requestFocus(); } });
    }

    private void showPlaylistsList() {
        openPlaylistName = null;
        playlistNames = prefs.getPlaylistNames();
        playlistAdapter = new StringAdapter(this, playlistNames, prefs, true);
        lvPlaylists.setAdapter(playlistAdapter);
        lvPlaylistSongs.setVisibility(View.GONE);
        lvPlaylists.setVisibility(View.VISIBLE);
        lvCentralMenu.setVisibility(View.GONE);
        lvMusic.setVisibility(View.GONE);
        lvPlaylists.post(new Runnable() { @Override public void run() { lvPlaylists.requestFocus(); } });
    }

    private void refreshOpenPlaylistSongs() {
        if (openPlaylistName == null) return;
        java.util.Set<String> ids = prefs.getPlaylistSongIds(openPlaylistName);
        int savedPos = readSelected(lvPlaylistSongs, currentPlaylistSongs.size());
        if (savedPos < 0) savedPos = 0;
        currentPlaylistSongs = new ArrayList<>();
        for (Song s : allSongs) {
            if (ids.contains(String.valueOf(s.getId()))) currentPlaylistSongs.add(s);
        }
        playlistSongsAdapter = new SongAdapter(this, currentPlaylistSongs, prefs, true);
        int clamped = (savedPos < currentPlaylistSongs.size()) ? savedPos : 0;
        lvPlaylistSongs.setAdapter(playlistSongsAdapter);
        lvPlaylistSongs.setSelection(clamped);
    }

    private void playSongFromList(final List<Song> songs, final int index) {
        if (songs == null || songs.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (now - lastPlayTime < 500) return;
        lastPlayTime = now;

        if (serviceBound) {
            musicService.setQueue(songs, index);
            queueAdapter = new SongAdapter(this, musicService.getQueue(), prefs, true);
            lvQueue.setAdapter(queueAdapter);
            switchToTab(TAB_NOW_PLAYING);
        } else {
            final Handler retryHandler = new Handler();
            final Runnable[] retry = new Runnable[1];
            final long start = System.currentTimeMillis();
            retry[0] = new Runnable() {
                @Override public void run() {
                    if (serviceBound) {
                        musicService.setQueue(songs, index);
                        queueAdapter = new SongAdapter(MainActivity.this, musicService.getQueue(), prefs, true);
                        lvQueue.setAdapter(queueAdapter);
                        switchToTab(TAB_NOW_PLAYING);
                    } else if (System.currentTimeMillis() - start < 3000) {
                        retryHandler.postDelayed(retry[0], 100);
                    }
                }
            };
            retryHandler.postDelayed(retry[0], 100);
        }
    }

    private void switchToTab(int index) {
        currentTab = index;
        showTab(index);
        refreshCurrentTab();
        focusCurrentVisibleListView();
    }

    /**
     * נותן מיקוד מקלדת (Android focus) ל-ListView הגלוי כרגע, כך שגלילת
     * D-pad תעבוד עליו מיד מבלי שהמשתמש יצטרך ללחוץ פעם נוספת. נקרא בכל
     * מעבר טאב/תת-מסך.
     */
    private void focusCurrentVisibleListView() {
        final ListView nativeLv = getCurrentVisibleListView();
        if (nativeLv == null) return;
        nativeLv.post(new Runnable() {
            @Override
            public void run() {
                nativeLv.requestFocus();
                if (nativeLv.getSelectedItemPosition() == ListView.INVALID_POSITION) {
                    nativeLv.setSelection(0);
                }
            }
        });
    }

    // ===================== KEY HANDLING =====================
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_1:
                toggleFavorite();
                return true;
            case KeyEvent.KEYCODE_2:
                adjustVolume(true);
                return true;
            case KeyEvent.KEYCODE_3:
                Song songFor3 = getSelectedSong();
                if (songFor3 != null) showAddToPlaylistDialog(songFor3);
                return true;
            case KeyEvent.KEYCODE_4:
                if (serviceBound) musicService.playPrevious();
                return true;
            case KeyEvent.KEYCODE_5:
                if (serviceBound) musicService.togglePlayPause();
                return true;
            case KeyEvent.KEYCODE_6:
                if (serviceBound) musicService.playNext();
                return true;
            case KeyEvent.KEYCODE_7:
                if (serviceBound) musicService.seekBackward(prefs.getJumpSeconds());
                return true;
            case KeyEvent.KEYCODE_8:
                adjustVolume(false);
                return true;
            case KeyEvent.KEYCODE_9:
                if (serviceBound) musicService.seekForward(prefs.getJumpSeconds());
                return true;
            case KeyEvent.KEYCODE_0:
                openSearch();
                return true;
            case KeyEvent.KEYCODE_MENU:
                showMainMenu();
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (currentTab == TAB_CENTRAL) {
                    if (centralSelectedOption != null && centralSelectedOption == CENTRAL_PLAYLISTS
                            && openPlaylistName != null) {
                        showPlaylistsList();
                        return true;
                    }
                    if (handleCentralBack()) return true;
                } else if (currentTab == TAB_GENRES && openGenreName != null) {
                    showGenresList();
                    return true;
                } else if (currentTab == TAB_ARTISTS && openArtistName != null) {
                    showArtistsList();
                    return true;
                } else if (currentTab == TAB_FOLDERS && openFolderName != null) {
                    showFoldersList();
                    return true;
                } else if (currentTab == TAB_FOLDERS && goUpFolder()) {
                    return true;
                }
                if (currentTab != TAB_CENTRAL) {
                    switchToTab(TAB_CENTRAL);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (currentTab > 0) switchToTab(currentTab - 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (currentTab < TAB_COUNT - 1) switchToTab(currentTab + 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN: {
                ListView nativeLv = getCurrentVisibleListView();
                if (nativeLv != null) {
                    nativeLv.requestFocus();
                    if (nativeLv.getSelectedItemPosition() == ListView.INVALID_POSITION) {
                        nativeLv.setSelection(0);
                        return true;
                    }
                    return nativeLv.onKeyDown(keyCode, event);
                }
                return true;
            }
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                selectCurrentItem();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * מחזיר את ה-ListView הגלוי כרגע לפי הטאב/תת-מסך הנוכחיים, כדי
     * שגלילת מקלדת/D-pad תמיד תעבור ישירות למנגנון הטבעי של אנדרואיד —
     * בדיוק כמו בטאב התיקיות.
     */
    private ListView getCurrentVisibleListView() {
        switch (currentTab) {
            case TAB_CENTRAL:
                if (centralSelectedOption == null) {
                    return lvCentralMenu;
                } else if (centralSelectedOption == CENTRAL_PLAYLISTS) {
                    return (openPlaylistName == null) ? lvPlaylists : lvPlaylistSongs;
                } else if (activeCentralSongs != null) {
                    return lvMusic;
                }
                return null;
            case TAB_GENRES:
                return (openGenreName == null) ? lvGenres : lvGenreSongs;
            case TAB_ARTISTS:
                return (openArtistName == null) ? lvArtists : lvArtistSongs;
            case TAB_ALBUMS:
                return lvAlbums;
            case TAB_FOLDERS:
                return (openFolderName == null) ? lvFolders : lvFolderSongs;
            case TAB_QUEUE:
                return lvQueue;
        }
        return null;
    }

    private void selectCurrentItem() {
        switch (currentTab) {
            case TAB_CENTRAL:
                if (centralSelectedOption == null) {
                    int pos = readSelected(lvCentralMenu, centralMenuItems.size());
                    if (pos >= 0) openCentralOption(pos);
                } else if (centralSelectedOption == CENTRAL_PLAYLISTS) {
                    if (openPlaylistName == null) {
                        if (playlistAdapter == null || playlistNames.isEmpty()) break;
                        int ppos = readSelected(lvPlaylists, playlistNames.size());
                        if (ppos >= 0) openPlaylist(playlistNames.get(ppos));
                    } else {
                        if (playlistSongsAdapter == null || currentPlaylistSongs.isEmpty()) break;
                        int pspos = readSelected(lvPlaylistSongs, currentPlaylistSongs.size());
                        if (pspos >= 0) playSongFromList(currentPlaylistSongs, pspos);
                    }
                } else if (activeCentralSongs != null && !activeCentralSongs.isEmpty()) {
                    int pos = readSelected(lvMusic, activeCentralSongs.size());
                    if (pos >= 0) playSongFromList(activeCentralSongs, pos);
                }
                break;
            case TAB_GENRES:
                if (openGenreName == null) {
                    int gpos = readSelected(lvGenres, genres.size());
                    if (gpos >= 0) openGenre(genres.get(gpos));
                } else {
                    int gspos = readSelected(lvGenreSongs, currentGenreSongs.size());
                    if (gspos >= 0) playSongFromList(currentGenreSongs, gspos);
                }
                break;
            case TAB_ARTISTS:
                if (openArtistName == null) {
                    int apos = readSelected(lvArtists, artists.size());
                    if (apos >= 0) openArtist(artists.get(apos));
                } else {
                    int aspos = readSelected(lvArtistSongs, currentArtistSongs.size());
                    if (aspos >= 0) playSongFromList(currentArtistSongs, aspos);
                }
                break;
            case TAB_ALBUMS: {
                int alpos = readSelected(lvAlbums, albums.size());
                if (alpos >= 0) {
                    List<Song> alSongs = MusicLoader.getSongsByAlbum(allSongs, albums.get(alpos));
                    playSongFromList(alSongs, 0);
                }
                break;
            }
            case TAB_FOLDERS:
                if (openFolderName == null) {
                    int fpos = readSelected(lvFolders, folders.size());
                    if (fpos >= 0) handleFolderTreeItemClick(fpos);
                } else {
                    int fspos = readSelected(lvFolderSongs, currentFolderSongs.size());
                    if (fspos >= 0) playSongFromList(currentFolderSongs, fspos);
                }
                break;
            case TAB_QUEUE:
                if (queueAdapter != null && serviceBound) {
                    int qpos = readSelected(lvQueue, musicService.getQueue().size());
                    if (qpos >= 0) {
                        musicService.playSongAtIndex(qpos);
                        switchToTab(TAB_NOW_PLAYING);
                    }
                }
                break;
        }
    }

    /**
     * קורא את המיקום שנבחר כרגע ב-ListView הטבעי, עם נפילה בטוחה למיקום 0
     * אם עדיין לא הופעל מיקוד (למשל מיד אחרי כניסה למסך).
     */
    private int readSelected(ListView lv, int size) {
        if (lv == null || size == 0) return -1;
        int pos = lv.getSelectedItemPosition();
        if (pos == ListView.INVALID_POSITION) pos = 0;
        if (pos < 0 || pos >= size) return -1;
        return pos;
    }

    private void toggleFavorite() {
        if (!serviceBound) return;
        Song current = musicService.getCurrentSong();
        if (current == null) return;
        prefs.toggleFavorite(current.getId());
        current.setFavorite(prefs.isFavorite(current.getId()));
        String msg = current.isFavorite() ?
                getString(R.string.added_to_favorites) : getString(R.string.removed_from_favorites);
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        refreshFavorites();
        if (musicAdapter != null) musicAdapter.notifyDataSetChanged();
    }

    private void adjustVolume(boolean up) {
        android.media.AudioManager am = (android.media.AudioManager)
                getSystemService(Context.AUDIO_SERVICE);
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                up ? android.media.AudioManager.ADJUST_RAISE
                   : android.media.AudioManager.ADJUST_LOWER,
                android.media.AudioManager.FLAG_SHOW_UI);
    }

    private void openSearch() {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            long songId = data.getLongExtra("song_id", -1);
            long[] resultIds = data.getLongArrayExtra("search_result_ids");
            int selectedIndex = data.getIntExtra("selected_index", -1);

            if (resultIds != null && resultIds.length > 0 && selectedIndex >= 0) {
                List<Song> searchQueue = new ArrayList<>();
                for (long id : resultIds) {
                    Song match = findSongById(allSongs, id);
                    if (match != null) searchQueue.add(match);
                }
                int newIndex = 0;
                for (int i = 0; i < searchQueue.size(); i++) {
                    if (searchQueue.get(i).getId() == songId) {
                        newIndex = i;
                        break;
                    }
                }
                if (!searchQueue.isEmpty()) {
                    playSongFromList(searchQueue, newIndex);
                    return;
                }
            }

            if (songId != -1) {
                for (int i = 0; i < allSongs.size(); i++) {
                    if (allSongs.get(i).getId() == songId) {
                        playSongFromList(allSongs, i);
                        break;
                    }
                }
            }
        }
    }

    // ===================== SERVICE CALLBACKS =====================
    @Override
    public void onSongChanged(final Song song) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateNowPlaying(song);
                if (queueAdapter != null && serviceBound) {
                    int qidx = musicService.getCurrentIndex();
                    queueAdapter.setPlayingPosition(qidx);
                }
                if (song != null) {
                    if (activeCentralAdapter != null && activeCentralSongs != null) {
                        int idx = findSongIndexById(activeCentralSongs, song.getId());
                        activeCentralAdapter.setPlayingPosition(idx); // -1 אם לא נמצא ברשימה הזו
                    }
                }
            }
        });
    }

    @Override
    public void onPlayStateChanged(final boolean isPlaying) {
        // הוסר הצגת טקסט "מתנגן/מושהה" - מצב הנגינה מועבר ויזואלית ע"י פס ההתקדמות בלבד
    }

    @Override
    public void onProgress(int currentMs, int totalMs) {
    }

    private void updateNowPlaying(Song song) {
        if (song == null) return;
        tvNowTitle.setText(song.getTitle());
        tvNowArtist.setText(song.getArtist());
        tvNowAlbum.setText(song.getAlbum());
        loadAlbumArt(song);
    }

    private void loadAlbumArt(Song song) {
        if (ivNowBackground == null || song == null) return;
        Bitmap albumArt = null;
        try {
            long albumId = song.getAlbumId();
            if (albumId >= 0) {
                Uri artUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"), albumId);
                java.io.InputStream in = null;
                try {
                    in = getContentResolver().openInputStream(artUri);
                    if (in != null) {
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inSampleSize = 2;
                        albumArt = BitmapFactory.decodeStream(in, null, opts);
                    }
                } finally {
                    if (in != null) try { in.close(); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {
            albumArt = null;
        }
        if (albumArt != null) ivNowBackground.setImageBitmap(albumArt);
        else ivNowBackground.setImageResource(R.drawable.default_album_art);
        ivNowBackground.setVisibility(View.VISIBLE);
    }

    /**
     * מפענח Bitmap מתוך מערך בייטים תוך "הקטנה" (subsample) לפי גודל יעד,
     * כדי למנוע קריסת OutOfMemoryError עם תמונות עטיפה גדולות/ברזולוציה
     * גבוהה - בעיה נפוצה במיוחד במכשירים ישנים עם מעט זיכרון.
     */
    private Bitmap decodeSampledBitmapFromByteArray(byte[] data, int reqWidth, int reqHeight) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, options);

            int sampleSize = 1;
            int halfHeight = options.outHeight / 2;
            int halfWidth = options.outWidth / 2;
            while ((halfHeight / sampleSize) >= reqHeight && (halfWidth / sampleSize) >= reqWidth) {
                sampleSize *= 2;
            }

            BitmapFactory.Options decodeOptions = new BitmapFactory.Options();
            decodeOptions.inSampleSize = sampleSize;
            return BitmapFactory.decodeByteArray(data, 0, data.length, decodeOptions);
        } catch (Throwable e) {
            return null;
        }
    }

    private void startProgressUpdater() {
        progressRunnable = new Runnable() {
            @Override
            public void run() {
                if (serviceBound && musicService != null && tvNowTime != null) {
                    int cur = musicService.getCurrentPosition();
                    int total = musicService.getDuration();
                    tvNowTime.setText(formatTime(cur) + " / " + formatTime(total));
                    if (pbNowProgress != null) {
                        if (total > 0) {
                            int progress = (int) (((long) cur * pbNowProgress.getMax()) / total);
                            pbNowProgress.setProgress(progress);
                        } else {
                            pbNowProgress.setProgress(0);
                        }
                    }
                }
                progressHandler.postDelayed(this, 1000);
            }
        };
        progressHandler.post(progressRunnable);
    }

    private String formatTime(int ms) {
        int secs = ms / 1000;
        return String.format("%d:%02d", secs / 60, secs % 60);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (genreAdapter != null) genreAdapter.notifyDataSetChanged();
        if (artistAdapter != null) artistAdapter.notifyDataSetChanged();
        if (albumAdapter != null) albumAdapter.notifyDataSetChanged();
        if (currentTab == TAB_CENTRAL && centralSelectedOption != null
                && centralSelectedOption == CENTRAL_PLAYLISTS) {
            refreshPlaylistsTab();
        }
    }

    // ===================== MAIN MENU (MENU KEY) - 7 אפשרויות =====================

    private void showMainMenu() {
        final Song currentSong = getSelectedSong();
        final boolean onSong = (currentSong != null);

        final String[] items = onSong ? new String[]{
                "🎵 אפשרויות שיר",
                "🎚️ אקולייזר",
                "😴 טיימר שינה",
                "🔍 חיפוש",
                "🔄 סרוק",
                "⚙️ הגדרות",
                "ℹ️ אודות",
                "❌ סגירת יישום"
        } : new String[]{
                "🎚️ אקולייזר",
                "😴 טיימר שינה",
                "🔍 חיפוש",
                "🔄 סרוק",
                "⚙️ הגדרות",
                "ℹ️ אודות",
                "❌ סגירת יישום"
        };

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.app_name)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        // אם יש שיר — האינדקס 0 הוא "אפשרויות שיר", שאר האפשרויות מוזזות ב-1
                        int offset = onSong ? 1 : 0;
                        if (onSong && which == 0) {
                            showSongOptionsMenu(currentSong);
                            return;
                        }
                        switch (which - offset) {
                            case 0:
                                startActivity(new Intent(MainActivity.this, EqualizerActivity.class));
                                break;
                            case 1:
                                startActivity(new Intent(MainActivity.this, SleepTimerActivity.class));
                                break;
                            case 2:
                                openSearch();
                                break;
                            case 3:
                                rescanLibrary();
                                break;
                            case 4:
                                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                                break;
                            case 5:
                                startActivity(new Intent(MainActivity.this, AboutActivity.class));
                                break;
                            case 6:
                                confirmCloseApp();
                                break;
                        }
                    }
                })
                .show();
    }

    /** תפריט אפשרויות לשיר המסומן כרגע */
    private void showSongOptionsMenu(final Song song) {
        final boolean isFav = prefs.isFavorite(song.getId());
        final String sourcePlaylist = (currentTab == TAB_CENTRAL
                && centralSelectedOption != null
                && centralSelectedOption == CENTRAL_PLAYLISTS) ? openPlaylistName : null;

        final List<String> opts = new ArrayList<>();
        opts.add(getString(R.string.menu_play));
        opts.add(getString(R.string.menu_play_next));
        opts.add(getString(R.string.menu_add_to_queue));
        opts.add(getString(R.string.menu_add_to_playlist));
        opts.add(isFav ? getString(R.string.menu_favorite_remove) : getString(R.string.menu_favorite_add));
        opts.add(getString(R.string.menu_share));
        opts.add(getString(R.string.menu_edit_tags));
        if (sourcePlaylist != null) opts.add(getString(R.string.menu_remove_from_playlist));
        opts.add(getString(R.string.menu_delete));

        final String[] items = opts.toArray(new String[0]);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(song.getTitle())
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String opt = items[which];
                        List<Song> single = new ArrayList<>();
                        single.add(song);
                        if (opt.equals(getString(R.string.menu_play))) {
                            playSongFromList(single, 0);
                        } else if (opt.equals(getString(R.string.menu_play_next))) {
                            if (serviceBound) {
                                musicService.insertNext(single);
                                Toast.makeText(MainActivity.this, "יתנגן אחרי השיר הנוכחי", Toast.LENGTH_SHORT).show();
                                refreshQueueIfVisible();
                            }
                        } else if (opt.equals(getString(R.string.menu_add_to_queue))) {
                            if (serviceBound) {
                                musicService.addToEnd(single);
                                Toast.makeText(MainActivity.this, "נוסף לתור", Toast.LENGTH_SHORT).show();
                                refreshQueueIfVisible();
                            }
                        } else if (opt.equals(getString(R.string.menu_add_to_playlist))) {
                            showAddToPlaylistDialog(song);
                        } else if (opt.equals(getString(R.string.menu_favorite_add))) {
                            prefs.toggleFavorite(song.getId());
                            song.setFavorite(true);
                            Toast.makeText(MainActivity.this, getString(R.string.added_to_favorites), Toast.LENGTH_SHORT).show();
                            refreshFavorites();
                        } else if (opt.equals(getString(R.string.menu_favorite_remove))) {
                            prefs.toggleFavorite(song.getId());
                            song.setFavorite(false);
                            Toast.makeText(MainActivity.this, getString(R.string.removed_from_favorites), Toast.LENGTH_SHORT).show();
                            refreshFavorites();
                        } else if (opt.equals(getString(R.string.menu_share))) {
                            shareSong(song);
                        } else if (opt.equals(getString(R.string.menu_edit_tags))) {
                            showEditTagsDialog(song);
                        } else if (opt.equals(getString(R.string.menu_remove_from_playlist))) {
                            removeSongFromPlaylist(song, sourcePlaylist);
                        } else if (opt.equals(getString(R.string.menu_delete))) {
                            List<Song> toDelete = new ArrayList<>();
                            toDelete.add(song);
                            confirmDeleteSongs(toDelete);
                        }
                    }
                })
                .show();
    }

    private void rescanLibrary() {
        loadMusic();
        if (centralSelectedOption != null) {
            openCentralOption(centralSelectedOption);
        }
        Toast.makeText(this, "הספרייה נסרקה מחדש", Toast.LENGTH_SHORT).show();
    }

    private void confirmCloseApp() {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle("❌ סגירת יישום")
                .setMessage("לסגור את האפליקציה?")
                .setPositiveButton(R.string.yes, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (serviceBound) {
                            try { unbindService(serviceConnection); } catch (Exception ignored) {}
                            serviceBound = false;
                        }
                        stopService(new Intent(MainActivity.this, MusicService.class));
                        finish();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private Song getSelectedSong() {
        switch (currentTab) {
            case TAB_CENTRAL:
                if (centralSelectedOption != null && centralSelectedOption == CENTRAL_PLAYLISTS) {
                    if (openPlaylistName != null && playlistSongsAdapter != null && !currentPlaylistSongs.isEmpty()) {
                        int pos = readSelected(lvPlaylistSongs, currentPlaylistSongs.size());
                        if (pos >= 0) return currentPlaylistSongs.get(pos);
                    }
                } else if (activeCentralAdapter != null && activeCentralSongs != null && !activeCentralSongs.isEmpty()) {
                    int pos = readSelected(lvMusic, activeCentralSongs.size());
                    if (pos >= 0) return activeCentralSongs.get(pos);
                }
                break;
            case TAB_GENRES:
                if (openGenreName != null && genreSongsAdapter != null && !currentGenreSongs.isEmpty()) {
                    int pos = readSelected(lvGenreSongs, currentGenreSongs.size());
                    if (pos >= 0) return currentGenreSongs.get(pos);
                }
                break;
            case TAB_ARTISTS:
                if (openArtistName != null && artistSongsAdapter != null && !currentArtistSongs.isEmpty()) {
                    int pos = readSelected(lvArtistSongs, currentArtistSongs.size());
                    if (pos >= 0) return currentArtistSongs.get(pos);
                }
                break;
            case TAB_FOLDERS:
                if (openFolderName != null && !currentFolderSongs.isEmpty()) {
                    int pos = readSelected(lvFolderSongs, currentFolderSongs.size());
                    if (pos >= 0) return currentFolderSongs.get(pos);
                }
                break;
            case TAB_QUEUE:
                if (queueAdapter != null && serviceBound && !musicService.getQueue().isEmpty()) {
                    List<Song> q = musicService.getQueue();
                    int pos = readSelected(lvQueue, q.size());
                    if (pos >= 0) return q.get(pos);
                }
                break;
            case TAB_NOW_PLAYING:
                if (serviceBound) return musicService.getCurrentSong();
                break;
        }
        return null;
    }

    // ===================== SONG CONTEXT MENU (לחיצה ארוכה) =====================

    /**
     * נקרא בלחיצה ארוכה על שיר.
     * אם כבר במצב בחירה — מסמן/מבטל סימון.
     * אחרת — נכנס למצב בחירה ומציג תפריט ראשוני (ביטול / בחר הכל / אפשרויות).
     */
    private void onSongLongClick(final SongAdapter adapter, final List<Song> list, final int position) {
        if (adapter == null || position < 0 || position >= list.size()) return;

        if (adapter.isSelectionMode()) {
            adapter.toggleSelection(position);
            return;
        }

        // בתור — תפריט מיוחד עם אפשרות הסרה
        if (currentTab == TAB_QUEUE && serviceBound) {
            final int queuePos = position;
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                    .setTitle(list.get(position).getTitle())
                    .setItems(new String[]{
                            getString(R.string.menu_cancel),
                            "❌ הסר מהתור",
                            getString(R.string.menu_options)
                    }, new android.content.DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(android.content.DialogInterface dialog, int which) {
                            switch (which) {
                                case 0: break; // ביטול
                                case 1: // הסר מהתור
                                    musicService.removeFromQueue(queuePos);
                                    queueAdapter = new SongAdapter(MainActivity.this,
                                            musicService.getQueue(), prefs, true);
                                    lvQueue.setAdapter(queueAdapter);
                                    Toast.makeText(MainActivity.this, "הוסר מהתור", Toast.LENGTH_SHORT).show();
                                    break;
                                case 2: // אפשרויות רגילות
                                    adapter.enterSelectionMode(queuePos);
                                    showSelectionActionsMenu(adapter, list, null);
                                    break;
                            }
                        }
                    })
                    .show();
            return;
        }

        // כניסה למצב בחירה — מסמן את השיר שנלחץ
        adapter.enterSelectionMode(position);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(list.get(position).getTitle())
                .setItems(new String[]{
                        getString(R.string.menu_cancel),
                        getString(R.string.menu_select_all),
                        getString(R.string.menu_options)
                }, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        switch (which) {
                            case 0: // ביטול
                                adapter.clearSelection();
                                break;
                            case 1: // בחר הכל
                                adapter.selectAll();
                                showSelectionActionsMenu(adapter, list, null);
                                break;
                            case 2: // אפשרויות
                                showSelectionActionsMenu(adapter, list, null);
                                break;
                        }
                    }
                })
                .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(android.content.DialogInterface dialog) {
                        adapter.clearSelection();
                    }
                })
                .show();
    }

    /**
     * תפריט האפשרויות המלא לשירים מסומנים (1+ שירים).
     * sourcePlaylist != null רק כשנמצאים בתוך פלייליסט ספציפי.
     */
    private void showSelectionActionsMenu(final SongAdapter adapter,
                                          final List<Song> list,
                                          final String sourcePlaylist) {
        final List<Song> selected = adapter.getSelectedSongs();
        if (selected.isEmpty()) { adapter.clearSelection(); return; }

        final boolean isSingle = (selected.size() == 1);
        final Song firstSong = selected.get(0);
        final boolean isFav = isSingle && prefs.isFavorite(firstSong.getId());

        List<String> options = new ArrayList<>();
        options.add(getString(R.string.menu_play));                                          // 0
        options.add(getString(R.string.menu_play_next));                                     // 1
        options.add(getString(R.string.menu_add_to_queue));                                  // 2
        options.add(getString(R.string.menu_add_to_playlist));                               // 3
        if (isSingle) {
            options.add(isFav ? getString(R.string.menu_favorite_remove)
                              : getString(R.string.menu_favorite_add));                      // 4
            options.add(getString(R.string.menu_share));                                     // 5
            options.add(getString(R.string.menu_edit_tags));                                 // 6
        }
        if (sourcePlaylist != null) {
            options.add(getString(R.string.menu_remove_from_playlist));
        }
        options.add(getString(R.string.menu_delete));

        final String[] items = options.toArray(new String[0]);
        String title = isSingle ? firstSong.getTitle()
                                : selected.size() + " שירים נבחרו";

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(title)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String opt = items[which];
                        if (opt.equals(getString(R.string.menu_play))) {
                            playSongFromList(selected, 0);
                        } else if (opt.equals(getString(R.string.menu_play_next))) {
                            if (serviceBound) {
                                musicService.insertNext(selected);
                                Toast.makeText(MainActivity.this,
                                        "יתנגן אחרי השיר הנוכחי", Toast.LENGTH_SHORT).show();
                                refreshQueueIfVisible();
                            }
                        } else if (opt.equals(getString(R.string.menu_add_to_queue))) {
                            if (serviceBound) {
                                musicService.addToEnd(selected);
                                Toast.makeText(MainActivity.this,
                                        selected.size() == 1 ? "נוסף לתור" : selected.size() + " שירים נוספו לתור",
                                        Toast.LENGTH_SHORT).show();
                                refreshQueueIfVisible();
                            }
                        } else if (opt.equals(getString(R.string.menu_add_to_playlist))) {
                            if (isSingle) showAddToPlaylistDialog(firstSong);
                            else showAddMultipleToPlaylistDialog(selected);
                        } else if (opt.equals(getString(R.string.menu_favorite_add))) {
                            prefs.toggleFavorite(firstSong.getId());
                            firstSong.setFavorite(true);
                            Toast.makeText(MainActivity.this,
                                    getString(R.string.added_to_favorites), Toast.LENGTH_SHORT).show();
                            refreshFavorites();
                        } else if (opt.equals(getString(R.string.menu_favorite_remove))) {
                            prefs.toggleFavorite(firstSong.getId());
                            firstSong.setFavorite(false);
                            Toast.makeText(MainActivity.this,
                                    getString(R.string.removed_from_favorites), Toast.LENGTH_SHORT).show();
                            refreshFavorites();
                        } else if (opt.equals(getString(R.string.menu_share))) {
                            shareSong(firstSong);
                        } else if (opt.equals(getString(R.string.menu_edit_tags))) {
                            showEditTagsDialog(firstSong);
                        } else if (opt.equals(getString(R.string.menu_remove_from_playlist))) {
                            for (Song s : selected) removeSongFromPlaylist(s, sourcePlaylist);
                        } else if (opt.equals(getString(R.string.menu_delete))) {
                            confirmDeleteSongs(selected);
                        }
                        adapter.clearSelection();
                    }
                })
                .setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(android.content.DialogInterface dialog) {
                        adapter.clearSelection();
                    }
                })
                .show();
    }

    private void showAddMultipleToPlaylistDialog(final List<Song> songs) {
        final List<String> names = new ArrayList<>(prefs.getPlaylistNames());
        final List<String> items = new ArrayList<>(names);
        items.add(getString(R.string.new_playlist));
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(getString(R.string.choose_playlist))
                .setItems(items.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == names.size()) {
                            promptNewPlaylistNameForMultiple(songs);
                        } else {
                            String pl = names.get(which);
                            for (Song s : songs) prefs.addSongToPlaylist(pl, s.getId());
                            Toast.makeText(MainActivity.this,
                                    songs.size() + " שירים נוספו", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).show();
    }

    private void promptNewPlaylistNameForMultiple(final List<Song> songs) {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.new_playlist)
                .setMessage(R.string.enter_playlist_name)
                .setView(input)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String name = input.getText().toString().trim();
                        if (!name.isEmpty()) {
                            for (Song s : songs) prefs.addSongToPlaylist(name, s.getId());
                            Toast.makeText(MainActivity.this,
                                    songs.size() + " שירים נוספו לרשימה " + name, Toast.LENGTH_SHORT).show();
                            refreshPlaylistsTab();
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void removeSongFromPlaylist(Song song, String playlist) {
        if (playlist == null) return;
        prefs.removeSongFromPlaylist(playlist, song.getId());
        refreshOpenPlaylistSongs();
    }

    private void confirmDeleteSongs(final List<Song> songs) {
        String msg = songs.size() == 1
                ? "האם למחוק את \"" + songs.get(0).getTitle() + "\"?"
                : "האם למחוק " + songs.size() + " שירים?";
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.menu_delete)
                .setMessage(msg)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        for (Song s : songs) deleteSong(s);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showEditTagsDialog(final Song song) {
        final EditText etTitle  = new EditText(this);
        final EditText etArtist = new EditText(this);
        final EditText etAlbum  = new EditText(this);
        etTitle.setHint("שם שיר");  etTitle.setText(song.getTitle());
        etArtist.setHint("אמן");    etArtist.setText(song.getArtist());
        etAlbum.setHint("אלבום");   etAlbum.setText(song.getAlbum());

        android.widget.LinearLayout ll = new android.widget.LinearLayout(this);
        ll.setOrientation(android.widget.LinearLayout.VERTICAL);
        ll.setPadding(40, 20, 40, 10);
        ll.addView(etTitle); ll.addView(etArtist); ll.addView(etAlbum);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(getString(R.string.menu_edit_tags))
                .setView(ll)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String newTitle  = etTitle.getText().toString().trim();
                        String newArtist = etArtist.getText().toString().trim();
                        String newAlbum  = etAlbum.getText().toString().trim();
                        if (!newTitle.isEmpty())  song.setTitle(newTitle);
                        if (!newArtist.isEmpty()) song.setArtist(newArtist);
                        if (!newAlbum.isEmpty())  song.setAlbum(newAlbum);
                        // שמירת תגיות קבצים — אם יש MediaStore write permission
                        updateSongMetadata(song);
                        refreshCurrentTab();
                        Toast.makeText(MainActivity.this, "תגיות עודכנו", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void refreshQueueIfVisible() {
        if (currentTab == TAB_QUEUE) {
            queueAdapter = new SongAdapter(this, musicService.getQueue(), prefs, true);
            lvQueue.setAdapter(queueAdapter);
        }
    }

    /** legacy — נשאר לתאימות לפונקציות ישנות */
    private void showSongMenu(final Song song, final String sourcePlaylist) {
        if (activeCentralAdapter != null && activeCentralSongs != null
                && activeCentralSongs.contains(song)) {
            activeCentralAdapter.enterSelectionMode(activeCentralSongs.indexOf(song));
            showSelectionActionsMenu(activeCentralAdapter, activeCentralSongs, sourcePlaylist);
        }
    }

    private void shareSong(Song song) {
        try {
            File file = new File(song.getPath());
            Uri uri = android.support.v4.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", file);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("audio/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, getString(R.string.share_song_title)));
        } catch (Exception e) {
            try {
                Uri contentUri = ContentUris.withAppendedId(
                        android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.getId());
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("audio/*");
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, getString(R.string.share_song_title)));
            } catch (Exception ex) {
                Toast.makeText(this, R.string.error_deleting_song, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showAddToPlaylistDialog(final Song song) {
        final List<String> names = new ArrayList<>(prefs.getPlaylistNames());
        final List<String> items = new ArrayList<>(names);
        items.add(getString(R.string.new_playlist));

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.choose_playlist)
                .setItems(items.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == names.size()) {
                            promptNewPlaylistName(song);
                        } else {
                            String playlistName = names.get(which);
                            prefs.addSongToPlaylist(playlistName, song.getId());
                            Toast.makeText(MainActivity.this, R.string.added_to_playlist, Toast.LENGTH_SHORT).show();
                            if (currentTab == TAB_CENTRAL && centralSelectedOption != null
                                    && centralSelectedOption == CENTRAL_PLAYLISTS) refreshPlaylistsTab();
                        }
                    }
                })
                .show();
    }

    private void promptNewPlaylistName(final Song songToAdd) {
        final EditText input = new EditText(this);
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.new_playlist)
                .setMessage(R.string.enter_playlist_name)
                .setView(input)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String name = input.getText().toString().trim();
                        if (!name.isEmpty()) {
                            prefs.createPlaylist(name);
                            if (songToAdd != null) {
                                prefs.addSongToPlaylist(name, songToAdd.getId());
                                Toast.makeText(MainActivity.this, R.string.added_to_playlist, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, R.string.playlist_created, Toast.LENGTH_SHORT).show();
                            }
                            if (currentTab == TAB_CENTRAL && centralSelectedOption != null
                                    && centralSelectedOption == CENTRAL_PLAYLISTS) refreshPlaylistsTab();
                        }
                    }
                })
                .setNegativeButton(R.string.menu_cancel, null)
                .show();
    }

    // ===================== PLAYLIST LONG-PRESS MENU =====================

    private void showPlaylistMenu(final String name) {
        String[] items = new String[]{
                getString(R.string.playlist_rename),
                getString(R.string.menu_delete)
        };

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(name)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) {
                            promptRenamePlaylist(name);
                        } else {
                            confirmDeletePlaylist(name);
                        }
                    }
                })
                .show();
    }

    private void promptRenamePlaylist(final String oldName) {
        final EditText input = new EditText(this);
        input.setText(oldName);
        input.setSelection(oldName.length());
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.playlist_rename)
                .setView(input)
                .setPositiveButton(android.R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String newName = input.getText().toString().trim();
                        if (!newName.isEmpty() && !newName.equals(oldName)) {
                            java.util.Set<String> songIds = prefs.getPlaylistSongIds(oldName);
                            prefs.createPlaylist(newName);
                            for (String id : songIds) {
                                try {
                                    prefs.addSongToPlaylist(newName, Long.parseLong(id));
                                } catch (NumberFormatException e) { }
                            }
                            prefs.deletePlaylist(oldName);
                            Toast.makeText(MainActivity.this, R.string.playlist_renamed, Toast.LENGTH_SHORT).show();
                            refreshPlaylistsTab();
                        }
                    }
                })
                .setNegativeButton(R.string.menu_cancel, null)
                .show();
    }

    private void removeSongFromCurrentPlaylist(Song song) {
        if (openPlaylistName == null) return;
        prefs.removeSongFromPlaylist(openPlaylistName, song.getId());
        Toast.makeText(this, R.string.removed_from_playlist, Toast.LENGTH_SHORT).show();
        refreshOpenPlaylistSongs();
    }

    private void confirmDeletePlaylist(final String name) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(name)
                .setMessage(R.string.delete_confirm_message)
                .setPositiveButton(R.string.yes, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        prefs.deletePlaylist(name);
                        Toast.makeText(MainActivity.this, R.string.playlist_deleted, Toast.LENGTH_SHORT).show();
                        refreshPlaylistsTab();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void confirmDeleteSong(final Song song) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_message)
                .setPositiveButton(R.string.yes, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        deleteSong(song);
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void deleteSong(Song song) {
        try {
            if (serviceBound && musicService.getCurrentSong() != null
                    && musicService.getCurrentSong().getId() == song.getId()) {
                musicService.playNext();
            }

            File file = new File(song.getPath());
            file.delete();

            getContentResolver().delete(
                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    android.provider.MediaStore.Audio.Media._ID + "=?",
                    new String[]{String.valueOf(song.getId())});

            if (prefs.isFavorite(song.getId())) {
                prefs.toggleFavorite(song.getId());
            }
            for (String pl : prefs.getPlaylistNames()) {
                prefs.removeSongFromPlaylist(pl, song.getId());
            }

            Toast.makeText(this, R.string.song_deleted, Toast.LENGTH_SHORT).show();

            loadMusic();
            refreshFavorites();
            if (currentTab == TAB_CENTRAL && centralSelectedOption != null
                    && centralSelectedOption == CENTRAL_PLAYLISTS) refreshPlaylistsTab();
            if (musicAdapter != null) musicAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            Toast.makeText(this, R.string.error_deleting_song, Toast.LENGTH_SHORT).show();
        }
    }

    /** עדכון מטא-דאטה של שיר ב-MediaStore */
    private void updateSongMetadata(Song song) {
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.Audio.Media.TITLE,  song.getTitle());
            cv.put(android.provider.MediaStore.Audio.Media.ARTIST, song.getArtist());
            cv.put(android.provider.MediaStore.Audio.Media.ALBUM,  song.getAlbum());
            getContentResolver().update(
                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    cv,
                    android.provider.MediaStore.Audio.Media._ID + "=?",
                    new String[]{String.valueOf(song.getId())});
        } catch (Exception e) {
            // אין הרשאת כתיבה — התגיות מעודכנות רק בזיכרון (עד הפעלה מחדש)
        }
    }

    @Override
    protected void onDestroy() {
        if (progressRunnable != null) progressHandler.removeCallbacks(progressRunnable);
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        super.onDestroy();
    }
}
