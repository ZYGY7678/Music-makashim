package com.musicapp.app.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import com.musicapp.app.models.Song;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MusicLoader {

    public static List<Song> loadAllSongs(Context context, AppPreferences prefs) {
        List<Song> songs = new ArrayList<>();
        Map<Long, String> genreMap = loadGenreMap(context);

        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.YEAR,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.IS_MUSIC
        };

        // מסנן קבצים קצרים מדי (פחות מ-5 שניות) כדי להוריד רעשים, אך כולל קבצים מוסתרים (עם נקודה)
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0"
                + " AND " + MediaStore.Audio.Media.DURATION + " > 5000";
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection, selection, null,
                    MediaStore.Audio.Media.TITLE + " ASC");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                    String artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                    String album = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                    long albumId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                    long duration = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                    String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                    int year = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR));
                    long dateAdded = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED));
                    String genre = genreMap.get(id);

                    Song song = new Song(id, title, artist, album, genre, year, duration, path, albumId, dateAdded);
                    song.setFavorite(prefs.isFavorite(id));
                    songs.add(song);
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) cursor.close();
        }
        return songs;
    }

    private static Map<Long, String> loadGenreMap(Context context) {
        Map<Long, String> map = new java.util.HashMap<>();
        Cursor genreCursor = null;
        try {
            genreCursor = context.getContentResolver().query(
                    MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME},
                    null, null, null);
            if (genreCursor != null && genreCursor.moveToFirst()) {
                do {
                    long genreId = genreCursor.getLong(
                            genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID));
                    String genreName = genreCursor.getString(
                            genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME));

                    Cursor memberCursor = null;
                    try {
                        Uri membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId);
                        memberCursor = context.getContentResolver().query(
                                membersUri,
                                new String[]{MediaStore.Audio.Genres.Members.AUDIO_ID},
                                null, null, null);
                        if (memberCursor != null && memberCursor.moveToFirst()) {
                            do {
                                long songId = memberCursor.getLong(
                                        memberCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID));
                                map.put(songId, genreName);
                            } while (memberCursor.moveToNext());
                        }
                    } finally {
                        if (memberCursor != null) memberCursor.close();
                    }
                } while (genreCursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (genreCursor != null) genreCursor.close();
        }
        return map;
    }

    /** מחזיר רשימת תיקיות ייחודיות (שם תיקייה) שיש בהן שירים */
    public static List<String> getFolders(List<Song> songs) {
        List<String> folders = new ArrayList<>();
        for (Song s : songs) {
            String folder = getFolderName(s.getPath());
            if (!folders.contains(folder)) {
                folders.add(folder);
            }
        }
        Collections.sort(folders);
        return folders;
    }

    /** מחזיר את שם התיקייה הישירה של הקובץ */
    public static String getFolderName(String path) {
        if (path == null) return "לא ידוע";
        File f = new File(path);
        File parent = f.getParentFile();
        return (parent != null) ? parent.getName() : "שורש";
    }

    /** מחזיר את הנתיב המלא של התיקייה */
    public static String getFolderPath(String path) {
        if (path == null) return "";
        File f = new File(path);
        File parent = f.getParentFile();
        return (parent != null) ? parent.getAbsolutePath() : "";
    }

    /** מחזיר שירים לפי שם תיקייה */
    public static List<Song> getSongsByFolder(List<Song> songs, String folderName) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (folderName.equals(getFolderName(s.getPath()))) result.add(s);
        }
        return result;
    }

    // ===================== עץ תיקיות אמיתי (כמו סייר קבצים) =====================

    /**
     * מחזיר את נתיב "השורש" המשותף לכל השירים — הנקודה הגבוהה ביותר
     * בעץ הקבצים שממנה מתחילים לנווט. מחושב אוטומטית לפי הנתיב
     * המשותף הארוך ביותר של כל תיקיות השירים, כך שזה עובד בכל מכשיר
     * (אחסון פנימי, כרטיס SD וכו') בלי תלות בנתיב ספציפי.
     */
    public static String getFolderTreeRoot(List<Song> songs) {
        String common = null;
        for (Song s : songs) {
            String folder = getFolderFullPath(s.getPath());
            if (folder == null || folder.isEmpty()) continue;
            if (common == null) {
                common = folder;
            } else {
                common = commonPathPrefix(common, folder);
            }
        }
        return (common == null || common.isEmpty()) ? "/" : common;
    }

    private static String commonPathPrefix(String a, String b) {
        String[] pa = a.split("/");
        String[] pb = b.split("/");
        StringBuilder sb = new StringBuilder();
        int n = Math.min(pa.length, pb.length);
        for (int i = 0; i < n; i++) {
            if (pa[i].equals(pb[i])) {
                if (sb.length() > 0 || !pa[i].isEmpty()) sb.append(pa[i]);
                sb.append("/");
            } else {
                break;
            }
        }
        String res = sb.toString();
        if (res.length() > 1 && res.endsWith("/")) res = res.substring(0, res.length() - 1);
        return res.isEmpty() ? "/" : res;
    }

    /** מחזיר את הנתיב המלא (אבסולוטי) של תיקיית האב של הקובץ */
    public static String getFolderFullPath(String path) {
        if (path == null) return "";
        File f = new File(path);
        File parent = f.getParentFile();
        return (parent != null) ? parent.getAbsolutePath() : "/";
    }

    /**
     * מחזיר את רשימת תתי-התיקיות הישירות של נתיב נתון (רק אלו שמכילות
     * שירים, ישירות או בתוך תתי-תיקיות שלהן) — בדיוק כמו בסייר קבצים.
     */
    public static List<String> getSubfolders(List<Song> songs, String currentPath) {
        java.util.LinkedHashSet<String> result = new java.util.LinkedHashSet<>();
        String prefix = currentPath.endsWith("/") ? currentPath : currentPath + "/";
        for (Song s : songs) {
            String folder = getFolderFullPath(s.getPath());
            if (folder.equals(currentPath)) continue;
            if (folder.startsWith(prefix)) {
                String rest = folder.substring(prefix.length());
                int slashIdx = rest.indexOf('/');
                String childName = (slashIdx >= 0) ? rest.substring(0, slashIdx) : rest;
                if (!childName.isEmpty()) result.add(childName);
            }
        }
        List<String> list = new ArrayList<>(result);
        Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
        return list;
    }

    /** מחזיר את השירים שנמצאים ישירות (לא בתתי-תיקיות) בנתיב נתון */
    public static List<Song> getSongsInFolderPath(List<Song> songs, String folderPath) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (folderPath.equals(getFolderFullPath(s.getPath()))) result.add(s);
        }
        return result;
    }

    /** מחזיר את הנתיב של תיקיית האב (תיקייה אחת למעלה), או null אם הגענו לשורש */
    public static String getParentFolderPath(String currentPath, String rootPath) {
        if (currentPath == null || currentPath.equals(rootPath)) return null;
        File f = new File(currentPath);
        File parent = f.getParentFile();
        if (parent == null) return null;
        String parentPath = parent.getAbsolutePath();
        // אם עלינו מעל השורש - נעצור בשורש
        if (rootPath.startsWith(parentPath) && !parentPath.equals(rootPath)) {
            return rootPath;
        }
        return parentPath;
    }

    public static List<String> getGenres(List<Song> songs) {
        List<String> genres = new ArrayList<>();
        for (Song s : songs) {
            if (s.getGenre() != null && !genres.contains(s.getGenre())) {
                genres.add(s.getGenre());
            }
        }
        Collections.sort(genres);
        return genres;
    }

    public static List<Song> getSongsByGenre(List<Song> songs, String genre) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (genre != null && genre.equals(s.getGenre())) result.add(s);
        }
        return result;
    }

    public static List<String> getArtists(List<Song> songs) {
        List<String> artists = new ArrayList<>();
        for (Song s : songs) {
            if (!artists.contains(s.getArtist())) artists.add(s.getArtist());
        }
        Collections.sort(artists);
        return artists;
    }

    public static List<String> getAlbums(List<Song> songs) {
        List<String> albums = new ArrayList<>();
        for (Song s : songs) {
            if (!albums.contains(s.getAlbum())) albums.add(s.getAlbum());
        }
        Collections.sort(albums);
        return albums;
    }

    public static List<Song> getSongsByArtist(List<Song> songs, String artist) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (s.getArtist().equals(artist)) result.add(s);
        }
        return result;
    }

    public static List<Song> getSongsByAlbum(List<Song> songs, String album) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (s.getAlbum().equals(album)) result.add(s);
        }
        return result;
    }

    public static List<Song> searchSongs(List<Song> songs, String query) {
        List<Song> result = new ArrayList<>();
        for (Song s : songs) {
            if (s.matchesQuery(query)) result.add(s);
        }
        return result;
    }
}
