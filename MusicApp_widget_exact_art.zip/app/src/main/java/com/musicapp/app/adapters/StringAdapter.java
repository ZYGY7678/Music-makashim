package com.musicapp.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.musicapp.app.R;
import com.musicapp.app.utils.AppPreferences;

import java.util.List;

public class StringAdapter extends ArrayAdapter<String> {
    private Context context;
    private List<String> items;
    private AppPreferences prefs;
    private int focusedPosition = 0;
    private boolean nativeMode = false; // true = גלילה טבעית של אנדרואיד (כמו בהגדרות)

    public StringAdapter(Context ctx, List<String> items, AppPreferences prefs) {
        this(ctx, items, prefs, false);
    }

    public StringAdapter(Context ctx, List<String> items, AppPreferences prefs, boolean nativeMode) {
        super(ctx, 0, items);
        this.context = ctx;
        this.items = items;
        this.prefs = prefs;
        this.nativeMode = nativeMode;
    }

    public int getFocusedPosition() { return focusedPosition; }
    public void setFocusedPosition(int pos) { this.focusedPosition = pos; }

    public void setFocusedPositionAndRefresh(int pos) {
        this.focusedPosition = pos;
        notifyDataSetChanged();
    }

    /**
     * הזזת סמן — קודם גוללים בפועל (ensureVisible), ואז מרעננים את כל
     * הרשימה כדי שהצביעה (highlight) תמיד תהיה נכונה, גם כשהשורות עוברות
     * מחזור (recycle) באמצע גלילה. notifyDataSetChanged קל מאוד ברשימות
     * האלו (תיקיות/סוגות/אמנים) ולכן אין בעיית ביצועים.
     */
    public void moveFocusTo(final int newPos, final ListView lv) {
        if (lv == null) return;
        focusedPosition = newPos;

        ensureVisible(lv, newPos);
        notifyDataSetChanged();
        // כשהרשימה לא גוללת בפועל (כל הפריטים כבר על המסך), notifyDataSetChanged
        // לבדו לפעמים לא מצייר מחדש שורות קיימות. invalidateViews מאלץ כל שורה
        // גלויה לעבור getView() מחדש באופן מיידי, בלי תלות בגלילה.
        lv.invalidateViews();
    }

    /**
     * מוודא שהשורה pos באמת גלויה ומגוללת אליה, גם ברשימות קצרות
     * שבהן setSelection הרגיל לא מזיז כלום כי "הכל כבר נראה גלוי".
     */
    private void ensureVisible(ListView lv, int pos) {
        int first = lv.getFirstVisiblePosition();
        int last = lv.getLastVisiblePosition();

        if (first == -1 || last == -1) {
            // הרשימה עוד לא עברה layout — setSelection רגיל מספיק
            lv.setSelection(pos);
            return;
        }

        if (pos < first) {
            // השורה מעל האזור הגלוי — גלול כך שתהיה למעלה
            lv.setSelectionFromTop(pos, 0);
        } else if (pos > last) {
            // השורה מתחת לאזור הגלוי — גלול כך שתהיה למטה
            int visibleCount = (last - first) + 1;
            int target = pos - visibleCount + 1;
            if (target < 0) target = 0;
            lv.setSelectionFromTop(target, 0);
        } else {
            // השורה כבר בתחום הנראה, אבל עדיין מעדכנים בחירה לוגית
            lv.setSelection(pos);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_simple, parent, false);
        }
        TextView tv = convertView.findViewById(R.id.tv_item);
        tv.setText(items.get(position));
        tv.setTextSize(prefs.getFontSize());

        if (nativeMode) {
            // אנדרואיד עצמו מצייר את הרקע (list_selector_native) לפי
            // מיקוד/לחיצה — לא נוגעים ברקע או בצבע ידנית.
            tv.setTextColor(prefs.getFontColor());
            return convertView;
        }

        if (position == focusedPosition) {
            convertView.setBackgroundColor(0xFF1A3A5C);
            tv.setTextColor(0xFFFFD700);
        } else {
            convertView.setBackgroundColor(0xFF1A1A2E);
            tv.setTextColor(prefs.getFontColor());
        }
        return convertView;
    }
}
