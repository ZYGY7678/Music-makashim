package com.musicapp.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.KeyEvent;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.musicapp.app.adapters.StringAdapter;
import com.musicapp.app.service.MusicService;
import com.musicapp.app.utils.AppPreferences;

import java.util.ArrayList;
import java.util.List;

public class SleepTimerActivity extends Activity {

    private static final int MODE_SONGS = 0;
    private static final int MODE_MINUTES = 1;

    private ListView lvOptions;
    private TextView tvStatus;
    private TextView btnModeSongs;
    private TextView btnModeMinutes;
    private StringAdapter adapter;
    private List<String> options = new ArrayList<>();
    private AppPreferences prefs;

    private int currentMode = MODE_SONGS;

    // 0=ביטול טיימר, 1..N=מספר שירים
    private int[] songValues = {0, 1, 2, 3, 5, 10, 15, 20};
    // 0=ביטול טיימר, 1..N=דקות
    private int[] minuteValues = {0, 5, 10, 15, 30, 45, 60, 90};

    private MusicService musicService;
    private boolean serviceBound = false;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            serviceBound = true;
            updateStatus();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_timer);
        prefs = new AppPreferences(this);

        lvOptions = (ListView) findViewById(R.id.lv_sleep_options);
        tvStatus = (TextView) findViewById(R.id.tv_sleep_status);
        btnModeSongs = (TextView) findViewById(R.id.btn_mode_songs);
        btnModeMinutes = (TextView) findViewById(R.id.btn_mode_minutes);

        // ברירת מחדל: מצב לפי מספר שירים
        currentMode = MODE_SONGS;

        buildOptionsForCurrentMode();

        adapter = new StringAdapter(this, options, prefs, true);
        lvOptions.setAdapter(adapter);

        lvOptions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectOption(position);
            }
        });

        btnModeSongs.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                switchMode(MODE_SONGS);
            }
        });

        btnModeMinutes.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                switchMode(MODE_MINUTES);
            }
        });

        updateModeButtons();

        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
    }

    /** בונה את רשימת האפשרויות המוצגת בהתאם למצב הנוכחי (שירים / דקות) */
    private void buildOptionsForCurrentMode() {
        options.clear();
        if (currentMode == MODE_SONGS) {
            for (int s : songValues) {
                if (s == 0) {
                    options.add("ביטול טיימר");
                } else {
                    options.add("כיבוי בעוד " + s + (s == 1 ? " שיר" : " שירים"));
                }
            }
        } else {
            for (int m : minuteValues) {
                if (m == 0) {
                    options.add("ביטול טיימר");
                } else {
                    options.add("כיבוי בעוד " + m + " דקות");
                }
            }
        }
    }

    private void switchMode(int mode) {
        if (currentMode == mode) return;
        currentMode = mode;
        buildOptionsForCurrentMode();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            lvOptions.setSelection(0);
        }
        updateModeButtons();
    }

    private void updateModeButtons() {
        if (currentMode == MODE_SONGS) {
            btnModeSongs.setBackgroundColor(0xFF1A3A5C);
            btnModeSongs.setTextColor(0xFFFFD700);
            btnModeMinutes.setBackgroundColor(0xFF2A2A4E);
            btnModeMinutes.setTextColor(0xFFFFFFFF);
        } else {
            btnModeMinutes.setBackgroundColor(0xFF1A3A5C);
            btnModeMinutes.setTextColor(0xFFFFD700);
            btnModeSongs.setBackgroundColor(0xFF2A2A4E);
            btnModeSongs.setTextColor(0xFFFFFFFF);
        }
    }

    private void updateStatus() {
        if (serviceBound && musicService.isSleepTimerActive()) {
            if (musicService.isSleepTimerSongMode()) {
                int remaining = musicService.getSleepTimerSongsRemaining();
                tvStatus.setText("הטיימר פעיל — כיבוי בעוד " + remaining + (remaining == 1 ? " שיר" : " שירים"));
            } else {
                int remaining = musicService.getSleepTimerMinutesRemaining();
                tvStatus.setText("הטיימר פעיל — נותרו כ-" + remaining + " דקות");
            }
        } else {
            tvStatus.setText("הטיימר אינו פעיל");
        }
    }

    private void selectOption(int position) {
        if (currentMode == MODE_SONGS) {
            if (position < 0 || position >= songValues.length) return;
            int songs = songValues[position];
            if (serviceBound) {
                musicService.setSleepTimerSongs(songs);
            }
            if (songs > 0) {
                prefs.setLastSleepTimerSongs(songs);
            }
        } else {
            if (position < 0 || position >= minuteValues.length) return;
            int minutes = minuteValues[position];
            if (serviceBound) {
                musicService.setSleepTimer(minutes);
            }
            if (minutes > 0) {
                prefs.setLastSleepTimerMinutes(minutes);
            }
        }
        updateStatus();
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN: {
                lvOptions.requestFocus();
                if (lvOptions.getSelectedItemPosition() == ListView.INVALID_POSITION) {
                    lvOptions.setSelection(0);
                    return true;
                }
                return lvOptions.onKeyDown(keyCode, event);
            }
            case KeyEvent.KEYCODE_DPAD_LEFT:
                switchMode(MODE_SONGS);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                switchMode(MODE_MINUTES);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER: {
                int pos = readSelected();
                if (pos >= 0) selectOption(pos);
                return true;
            }
            case KeyEvent.KEYCODE_BACK:
                finish();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * קורא את המיקום שנבחר כרגע ב-ListView הטבעי, עם נפילה בטוחה למיקום 0
     * אם עדיין לא הופעל מיקוד (למשל מיד אחרי כניסה למסך).
     */
    private int readSelected() {
        if (lvOptions == null || options.isEmpty()) return -1;
        int pos = lvOptions.getSelectedItemPosition();
        if (pos == ListView.INVALID_POSITION) pos = 0;
        if (pos < 0 || pos >= options.size()) return -1;
        return pos;
    }
}
