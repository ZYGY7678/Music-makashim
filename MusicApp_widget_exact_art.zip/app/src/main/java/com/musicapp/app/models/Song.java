package com.musicapp.app.models;

public class Song {
    private long id;
    private String title;
    private String artist;
    private String album;
    private String genre;
    private int year;
    private long duration;
    private String path;
    private boolean isFavorite;
    private long albumId;
    private long dateAdded; // שניות מאז epoch, מ-MediaStore.DATE_ADDED — לטור "נוספו לאחרונה"

    public Song(long id, String title, String artist, String album,
                String genre, int year, long duration, String path, long albumId) {
        this(id, title, artist, album, genre, year, duration, path, albumId, 0);
    }

    public Song(long id, String title, String artist, String album,
                String genre, int year, long duration, String path, long albumId, long dateAdded) {
        this.id = id;
        this.title = title != null ? title : "Unknown Title";
        this.artist = artist != null ? artist : "Unknown Artist";
        this.album = album != null ? album : "Unknown Album";
        this.genre = (genre != null && !genre.trim().isEmpty()) ? genre : "ללא ז'אנר";
        this.year = year;
        this.duration = duration;
        this.path = path;
        this.isFavorite = false;
        this.albumId = albumId;
        this.dateAdded = dateAdded;
    }

    public long getDateAdded() { return dateAdded; }

    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public String getAlbum() { return album; }
    public String getGenre() { return genre; }
    public int getYear() { return year; }
    public long getDuration() { return duration; }
    public String getPath() { return path; }
    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }
    public void setTitle(String title)   { if (title  != null && !title.isEmpty())  this.title  = title; }
    public void setArtist(String artist) { if (artist != null && !artist.isEmpty()) this.artist = artist; }
    public void setAlbum(String album)   { if (album  != null && !album.isEmpty())  this.album  = album; }
    public long getAlbumId() { return albumId; }

    public String getDisplayDuration() {
        long mins = duration / 1000 / 60;
        long secs = (duration / 1000) % 60;
        return String.format("%d:%02d", mins, secs);
    }

    public boolean matchesQuery(String query) {
        if (query == null || query.isEmpty()) return true;
        String q = query.toLowerCase();
        return title.toLowerCase().contains(q)
                || artist.toLowerCase().contains(q)
                || album.toLowerCase().contains(q)
                || genre.toLowerCase().contains(q)
                || String.valueOf(year).contains(q)
                || path.toLowerCase().contains(q);
    }
}
